"""
Centralized settings. The Anthropic API key lives only here, server-side —
it never reaches the browser.
"""
import os
from pathlib import Path

from dotenv import load_dotenv

from core import model_policy as _policy

from core import model_policy as _policy
# Load backend/.env so keys in that file reach os.environ.
load_dotenv(Path(__file__).parent.parent / ".env")


class Settings:
    anthropic_api_key: str = os.environ.get("ANTHROPIC_API_KEY", "")
    model: str = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")
    
    # Gemini
    gemini_api_key: str = os.environ.get("GEMINI_API_KEY", os.environ.get("GOOGLE_API_KEY", ""))
    gemini_model: str = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")

    # OpenRouter — the third backbone (see core/llm_client.py's provider
    # docstring). One key gives access to open-weight models (DeepSeek/Qwen/
    # Llama and their many variants) through the same OpenAI-compatible
    # /v1/chat/completions shape every self-hosted serving stack (vLLM,
    # SGLang, Ollama) also speaks — chosen deliberately so swapping this key
    # for a self-hosted endpoint later is a base_url change, not a rewrite.
    openrouter_api_key: str = os.environ.get("OPENROUTER_API_KEY", "")
    # Overridable so a self-hosted vLLM/SGLang endpoint can be swapped in
    # later without touching any code — same OpenAI-compatible shape either way.
    openrouter_base_url: str = os.environ.get("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")

    # The Home page's "Discuss with Sift AI" lite agent (api/routes.py's
    # /api/quick-ask, "projects" scope) — an open-weight model via OpenRouter
    # by design, so moving it to a self-hosted GPU later is just changing
    # openrouter_base_url above plus this one model id, nothing else.
    # Verify the exact current slug on openrouter.ai/models before relying on
    # it — model ids there get renamed/retired over time.
    quick_ask_model: str = os.environ.get("QUICK_ASK_MODEL", "deepseek/deepseek-chat")

    # ── Pipeline routing & limits ────────────────────────────────────────
    # Defaults live in the version-controlled core/model_policy.py (so they
    # survive .env resets); .env vars below override them per-environment.
    # Routing: mechanical stages → FAST_MODEL, synthesis/eval → MID_MODEL,
    # and the model the USER selects is reserved for the Writer.
    search_limit: int = int(os.environ.get("SEARCH_LIMIT", str(_policy.SEARCH_LIMIT)))
    per_purpose_routing: bool = (
        os.environ.get("PER_PURPOSE_ROUTING", "1" if _policy.PER_PURPOSE_ROUTING else "0")
        not in ("0", "false", "False")
    )
    fast_model: str = os.environ.get("FAST_MODEL", _policy.FAST_MODEL)
    mid_model: str = os.environ.get("MID_MODEL", _policy.MID_MODEL)
    # Empty = use the user-selected model for the Writer; set to pin it.
    write_model: str = os.environ.get("WRITE_MODEL", _policy.WRITE_MODEL)

    cors_origin: str = os.environ.get("CORS_ORIGIN", "http://localhost:5173")
    # SQLite path — overridable via DB_PATH env var for cloud deployment
    db_path: str = os.environ.get("DB_PATH", str(Path(__file__).parent.parent / "sift.db"))
    
    # Semantic Scholar
    s2_api_key: str = os.environ.get("S2_API_KEY", "")
    
    # Unpaywall
    unpaywall_email: str = os.environ.get("UNPAYWALL_EMAIL", "research@example.com")
    
    # PubMed
    ncbi_api_key: str = os.environ.get("NCBI_API_KEY", "")
    ncbi_email: str = os.environ.get("NCBI_EMAIL", "")
    ncbi_tool: str = os.environ.get("NCBI_TOOL", "sift")

    # IEEE Xplore Metadata API — free registered key, ~200 calls/day on the
    # free tier, metadata only (no full text without an institutional
    # subscription). Source is skipped silently when unset — see
    # agents/academic_search.py's _ieee().
    ieee_api_key: str = os.environ.get("IEEE_API_KEY", "")

    # SerpApi (Google Patents) — third-party, paid beyond a small free trial
    # quota. Source is skipped silently when unset.
    serpapi_key: str = os.environ.get("SERPAPI_KEY", "")

    # ClinicalTrials.gov — no key needed, always on.
    # CrossRef — no key needed; a contact email is sent per their "polite
    # pool" convention for better rate limits (reuses the Unpaywall email).

    # Supabase auth. Legacy projects sign JWTs with HS256 + this shared secret;
    # newer projects use asymmetric keys (ES256/RS256) verified via the project's
    # JWKS endpoint, which needs the project URL. Either path is supported.
    supabase_jwt_secret: str = os.environ.get("SUPABASE_JWT_SECRET", "")
    supabase_url: str = os.environ.get("SUPABASE_URL", "")
    cors_origin: str = os.environ.get("CORS_ORIGIN", "http://localhost:5173")
    
    # SQLite path — overridable via DB_PATH env var for cloud deployment
    db_path: str = os.environ.get("DB_PATH", str(Path(__file__).parent.parent / "sift.db"))

    # Where locally-uploaded source files (PDF/DOCX added via Sources >
    # "Upload a file") are stored on disk, keyed by run id. Overridable via
    # UPLOADS_DIR for deployments with a mounted/persistent volume.
    uploads_dir: str = os.environ.get("UPLOADS_DIR", str(Path(__file__).parent.parent / "data" / "uploads"))

    # Public "Contact us" form (About page). Cloudflare Email Routing only
    # forwards mail that actually arrives at contact_to_email over SMTP — it
    # can't see HTTP form submissions — so the backend sends a real outbound
    # email TO that address via Resend's API, and Cloudflare's already-
    # configured routing rule takes it from there (forwarding to whatever
    # inbox it's set to point at today, with no code change needed if that
    # inbox changes later).
    resend_api_key: str = os.environ.get("RESEND_API_KEY", "")
    # Must be a sender address on a domain verified in Resend (e.g.
    # noreply@orcusintelligencelab.com) — defaults to Resend's shared test
    # sender, which only delivers to the Resend account's own verified email,
    # so the real domain must be verified for production use.
    contact_from_email: str = os.environ.get("CONTACT_FROM_EMAIL", "onboarding@resend.dev")
    contact_to_email: str = os.environ.get("CONTACT_TO_EMAIL", "contact@orcusintelligencelab.com")

    # Careers page "Apply" form — same Resend delivery path as the contact
    # form above, just a different recipient and a multipart body (resume +
    # cover letter attachments) instead of a plain text message.
    hr_email: str = os.environ.get("HR_EMAIL", "hr@orcusintelligencelab.com")


settings = Settings()
