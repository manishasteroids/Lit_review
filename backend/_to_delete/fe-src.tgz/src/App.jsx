import React, { useState, useRef, useEffect, useCallback } from "react";
import { api } from "./api/client.js";
import { ensureAuth, useSession, useAuthReady } from "./Auth.jsx";
import { authEnabled } from "./supabase.js";

import PipelineRail from "./components/PipelineRail.jsx";
import QueryInput, { ModeBar } from "./components/QueryInput.jsx";
import UnderstandingCard from "./components/UnderstandingCard.jsx";
import PaperFilter from "./components/PaperFilter.jsx";
import ReviewView from "./components/ReviewView.jsx";
import SourcesView from "./components/SourcesView.jsx";
import CritiqueView from "./components/CritiqueView.jsx";
import KnowledgeGraphView from "./components/KnowledgeGraphView.jsx";
import DataAnalysisView from "./components/DataAnalysisView.jsx";
import EvaluationView from "./components/EvaluationView.jsx";
import UsageView from "./components/UsageView.jsx";
import PlanPanel from "./components/PlanPanel.jsx";
import LandingPage from "./components/LandingPage.jsx";
import HistoryView from "./components/HistoryView.jsx";
import ProfileModal from "./components/ProfileModal.jsx";
import ProjectsModal from "./components/ProjectsModal.jsx";
import ExportBar from "./components/ExportBar.jsx";
import StudioView from "./components/StudioView.jsx";
import Sidebar from "./components/Sidebar.jsx";
import HomePage from "./components/HomePage.jsx";
import PhysicalAIView from "./components/PhysicalAIView.jsx";
import DataAnalysisPlaceholder from "./components/DataAnalysisPlaceholder.jsx";
import DataAnalysisAgentView from "./components/DataAnalysisAgentView.jsx";
import { useConfirm } from "./components/ConfirmModal.jsx";
import {
  RotateCw, AlertTriangle, Sparkles, PenTool,
  BookOpen, Layers, Brain, Network, BarChart3, FlaskConical,
  Plus, Trash2, Coins, Clock, MessageSquare, ArrowLeft, Folder, ChevronDown,
  Lightbulb,
} from "./components/icons.jsx";

import MethodsPanel from "./components/MethodsPanel.jsx";
import HypothesisAgentPanel from "./components/HypothesisAgentPanel.jsx";
import HypothesisPipelineRail from "./components/HypothesisPipelineRail.jsx";
import PublishPanel from "./components/PublishPanel.jsx";

// Source icons shown in the progress feed
const SOURCE_ICON = {
  semantic_scholar: "🔬",
  arxiv: "📄",
  pubmed: "🧬",
  openalex: "🌐",
  crossref: "🔗",
  clinicaltrials: "⚕️",
  ieee: "⚡",
  patents: "📜",
};

const TOOLS = [
  ["review", BookOpen, "Review"],
  ["sources", Layers, "Sources"],
  ["critique", Brain, "Critique"],
  ["graph", Network, "Knowledge graph"],
  ["data", BarChart3, "Data analysis"],
  ["eval", FlaskConical, "Evaluation"],
];
// Not in this list on purpose:
//  - Methods (the first, two-hypothesis version of hypothesis generation) is
//    retired: Infinity does the same job with its refine loop and export
//    carried over. MethodsPanel.jsx stays because Infinity's panel reuses
//    its citation/score components.
//  - Hypothesis generation is its own agent (Infinity), so it gets the
//    "Want to generate hypotheses?" card under Tools instead of a row here.
//  - Token usage lives on the Account and Billing page.

// The standalone Hypothesis workspace (Flow B, sidebar's "Hypothesis
// Generation" entry) gets its own small Tools list rather than Sift's full
// one -- only the companion views that make sense while reading/critiquing
// hypotheses for an already-completed Literature Review. Same underlying
// components as Sift's own tabs (same session data), just a narrower menu.
const HYP_TOOLS = [
  ["hypothesis", Lightbulb, "Hypothesis"],
  ["sources", Layers, "Sources"],
  ["review", BookOpen, "Review"],   // after Sources: analysing the sources is what produces the review
  ["graph", Network, "Knowledge graph"],
];

// ── History helpers ──────────────────────────────────────────────
function relativeTime(iso) {
  if (!iso) return "";
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return Math.floor(diff / 60) + "m ago";
  if (diff < 86400) return Math.floor(diff / 3600) + "h ago";
  if (diff < 2592000) return Math.floor(diff / 86400) + "d ago";
  return new Date(iso).toLocaleDateString();
}

// Absolute timestamp in the user's chosen profile timezone (falls back to
// the browser's own timezone when `tz` is empty/invalid — see ProfileModal's
// "Auto-detect" option, which saves "" for exactly this reason).
function formatTimestamp(iso, tz) {
  if (!iso) return "";
  const opts = { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" };
  try {
    return new Date(iso).toLocaleString(undefined, tz ? { ...opts, timeZone: tz } : opts);
  } catch {
    return new Date(iso).toLocaleString(undefined, opts);
  }
}

// Short date for the narrow History rail: the time for today's runs, the day
// otherwise ("Sep 14"), with the year only when it isn't this year. The full
// timestamp stays available as the row's tooltip.
function formatShortDate(iso, tz) {
  if (!iso) return "";
  const d = new Date(iso), now = new Date();
  const zone = tz ? { timeZone: tz } : {};
  const fmt = (o) => { try { return d.toLocaleString(undefined, { ...o, ...zone }); } catch { return d.toLocaleString(undefined, o); } };
  if (now - d < 86400000 && d.getDate() === now.getDate()) return fmt({ hour: "numeric", minute: "2-digit" });
  return fmt(d.getFullYear() === now.getFullYear() ? { month: "short", day: "numeric" } : { month: "short", day: "numeric", year: "numeric" });
}

function groupSessions(sessions) {
  const now = Date.now();
  const buckets = { Today: [], Yesterday: [], "This week": [], Older: [] };
  for (const s of sessions) {
    const diff = (now - new Date(s.updated_at).getTime()) / 1000;
    if (diff < 86400) buckets["Today"].push(s);
    else if (diff < 172800) buckets["Yesterday"].push(s);
    else if (diff < 604800) buckets["This week"].push(s);
    else buckets["Older"].push(s);
  }
  return buckets;
}

// Inline styles for the History list (no extra CSS needed)
const H = {
  head: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  newBtn: { background: "none", border: "1px solid var(--line)", borderRadius: 7, color: "var(--muted)", cursor: "pointer", padding: "3px 5px", display: "flex", alignItems: "center" },
  empty: { fontFamily: "'JetBrains Mono',monospace", fontSize: 11, color: "var(--muted2)", lineHeight: 1.6, padding: "8px 2px" },
  scroll: { maxHeight: "max(260px, calc(100vh - 380px))", overflowY: "auto", margin: "0 -4px", padding: "0 4px" },
  search: { width: "100%", boxSizing: "border-box", padding: "6px 9px", marginBottom: 6, borderRadius: 7, border: "1px solid var(--line)", background: "var(--card,#fff)", color: "var(--txt)", fontFamily: "inherit", fontSize: 12, outline: "none" },
  count: { fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: "var(--muted2)" },
  proj: { display: "flex", alignItems: "center", gap: 5, marginTop: 4, fontSize: 11, color: "var(--muted)", minWidth: 0 },
  projName: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", minWidth: 0 },
  bucket: { fontFamily: "'JetBrains Mono',monospace", fontSize: 9.5, fontWeight: 500, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--muted2)", padding: "10px 4px 4px" },
  item: { padding: "8px 9px", borderRadius: 8, cursor: "pointer", marginBottom: 2 },
  itemActive: { background: "var(--indigo-soft)" },
  itemTop: { display: "flex", alignItems: "flex-start", gap: 4, justifyContent: "space-between" },
  itemTopic: { fontSize: 12.5, color: "var(--txt)", lineHeight: 1.35, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", flex: 1, minWidth: 0 },
  del: { background: "none", border: "none", cursor: "pointer", color: "var(--muted2)", padding: "2px 3px", borderRadius: 4, display: "flex", alignItems: "center", flexShrink: 0 },
  delConfirm: { color: "#f08a8a" },
  meta: { display: "flex", alignItems: "center", gap: 5, marginTop: 5, fontFamily: "'JetBrains Mono',monospace", fontSize: 10, color: "var(--muted)", whiteSpace: "nowrap", overflow: "hidden" },
  dot: { color: "var(--muted2)" },
  badge: { fontFamily: "'JetBrains Mono',monospace", fontSize: 9.5, fontWeight: 500, borderRadius: 4, padding: "1px 5px" },
  badgeDone: { background: "var(--green-soft)", color: "var(--green)" },
  badgeFilter: { background: "rgba(224,163,62,.14)", color: "var(--amber)" },
  foot: { marginTop: 12, paddingTop: 10, borderTop: "1px solid var(--line)", fontFamily: "'JetBrains Mono',monospace", fontSize: 9.5, color: "var(--muted2)", lineHeight: 1.5 },
  // Signed-out history prompt (SciSpace-style)
  loginCard: { border: "1px solid var(--line)", borderRadius: 10, padding: "12px 12px 13px", background: "var(--indigo-soft)" },
  loginText: { fontSize: 12, color: "var(--txt)", lineHeight: 1.5, marginBottom: 10 },
};

// "+ New" dropdown menu + inline "New project" popover, anchored under the button.
const NEWMENU = {
  menu: {
    position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0, zIndex: 30,
    background: "var(--card,#fff)", border: "1px solid var(--line)", borderRadius: 10,
    boxShadow: "0 10px 28px rgba(0,0,0,.14)", padding: 5,
  },
  item: {
    display: "block", width: "100%", textAlign: "left", background: "none", border: "none",
    borderRadius: 7, padding: "8px 9px", fontSize: 12.5, color: "var(--txt)", cursor: "pointer",
    fontFamily: "inherit",
  },
  item2: {
    display: "flex", alignItems: "flex-start", gap: 10, width: "100%", textAlign: "left",
    background: "none", border: "none", borderRadius: 8, padding: "9px 10px", cursor: "pointer",
    fontFamily: "inherit",
  },
  itemIc: {
    flex: "0 0 26px", width: 26, height: 26, borderRadius: 7, background: "var(--indigo-soft)",
    color: "var(--indigo)", display: "flex", alignItems: "center", justifyContent: "center", marginTop: 1,
  },
  itemTitle: { display: "block", fontSize: 13, fontWeight: 600, color: "var(--txt)" },
  itemSub: { display: "block", fontSize: 11, color: "var(--muted)", marginTop: 1 },
  popover: {
    position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0, zIndex: 31,
    background: "var(--card,#fff)", border: "1px solid var(--line)", borderRadius: 10,
    boxShadow: "0 10px 28px rgba(0,0,0,.14)", padding: 10,
  },
  input: {
    width: "100%", padding: "8px 10px", borderRadius: 7, border: "1px solid var(--line)",
    fontFamily: "inherit", fontSize: 13, color: "var(--txt)", background: "var(--ink)",
    outline: "none", boxSizing: "border-box",
  },
};

// "File next search under…" chip + popover in the sidebar Project panel.
const PICK = {
  chip: {
    display: "flex", alignItems: "center", gap: 6, width: "100%", textAlign: "left",
    background: "var(--card,#fff)", border: "1px solid var(--line)", borderRadius: 8,
    padding: "7px 9px", cursor: "pointer", fontFamily: "inherit", color: "var(--txt)",
  },
  chipLabel: {
    flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
    fontSize: 12.5, fontWeight: 500,
  },
  itemActive: { background: "var(--indigo-soft)", color: "var(--indigo)", fontWeight: 600 },
};

export default function App() {
  const session = useSession();
  const authReady = useAuthReady();
  const signedOut = authEnabled && !session;

  const [apiKey, setApiKey] = useState("");
  const [model, setModel] = useState("claude-sonnet-4-6");  // still used for paper chat
  const [confirmAsync, confirmModal] = useConfirm();
  const [mode, setMode] = useState("medium");               // search mode drives the pipeline
  const [modes, setModes] = useState([]);
  const [topic, setTopic] = useState("");
  const [stage, setStage] = useState("query");
  const [done, setDone] = useState({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  // Set when the user's plan downgraded the requested search mode (trial over)
  const [planNotice, setPlanNotice] = useState(null);

  const [notes, setNotes] = useState({}); // paper idx -> note text
  const [accountTab, setAccountTab] = useState(null);  // "profile" | "settings" | null
  const [showProjects, setShowProjects] = useState(false);
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState("");  // project to file the NEXT run under
  const [currentProject, setCurrentProject] = useState(null);  // the project workspace you're "inside", if any
  const [newMenuOpen, setNewMenuOpen] = useState(false);
  const [newProjectOpen, setNewProjectOpen] = useState(false);
  const [newProjectName, setNewProjectName] = useState("");
  const [newProjectBusy, setNewProjectBusy] = useState(false);
  const [newProjectErr, setNewProjectErr] = useState(null);
  const [projectPickerOpen, setProjectPickerOpen] = useState(false); // "file next search under..." popover
  const [pickerNewOpen, setPickerNewOpen] = useState(false);
  const [pickerNewName, setPickerNewName] = useState("");
  const [pickerBusy, setPickerBusy] = useState(false);

  // Dashboard shell (architecture doc: claude/architecture-dashboard-upgrade.md,
  // Phase 1). "home" is the post-login landing page; "workspace" is the
  // existing Sift single-page layout below, unchanged; the other two are
  // placeholders per the doc's phased plan.
  const [view, setView] = useState("home");
  const [dataAnalysisWhich, setDataAnalysisWhich] = useState("dataviz");

  // `view` lives in memory for the whole browser tab and isn't reset just
  // because the user signed out — signing out only flips `signedOut` (which
  // makes the top-level render swap in <LandingPage/>), it doesn't unmount
  // this component or its state. So if someone was sitting on, say, the
  // "workspace" view, got signed out (token expiry, clicking Sign out, etc.),
  // and then logged back in from the landing page WITHOUT a full page
  // refresh, the app would silently resume that exact stale view — landing
  // them back in the middle of the old Sift tool with no way to reach the
  // Home dashboard's persistent nav, since that nav only renders for
  // view === "home". A plain refresh doesn't have this problem (a fresh
  // mount always starts at "home"), which is what made this look
  // refresh-dependent rather than a real bug. Explicitly reset to "home" on
  // every signed-out -> signed-in transition so a fresh login always behaves
  // like a fresh page load.
  const prevSignedOutRef = useRef(signedOut);
  useEffect(() => {
    if (prevSignedOutRef.current && !signedOut) {
      setView("home");
    }
    prevSignedOutRef.current = signedOut;
  }, [signedOut]);
  // Home's "Discuss with Sift AI" box sets topic + flips this, so the actual
  // runStart() call happens once we've switched into the workspace view
  // (avoids calling it against stale/mid-transition state).
  const [autoStartTopic, setAutoStartTopic] = useState(false);
  // "create" when the sidebar's "Create new project" button opened
  // ProjectsModal (so it lands straight in the create-project form); null
  // for the normal "browse my projects" open.
  const [projectsInitialMode, setProjectsInitialMode] = useState(null);

  const refreshProjects = useCallback(() => {
    if (signedOut) { setProjects([]); return; }
    api.listProjects().then((d) => setProjects(d.projects || [])).catch(() => {});
  }, [signedOut]);
  useEffect(() => { refreshProjects(); }, [refreshProjects]);

  // Re-fetch the project you're currently "inside" (its run list, mainly) —
  // used after an action that changes which runs belong to it, e.g. filing
  // an existing History run under it. Set via setCurrentProject with a
  // functional update so it only touches state if you're still in the same
  // project by the time the fetch resolves (nothing to do if you navigated
  // away, and nothing to overwrite with if you'd switched to a different one).
  const refreshCurrentProject = useCallback(() => {
    setCurrentProject((cur) => {
      if (!cur) return cur;
      api.getProject(cur.id).then((p) => {
        if (p && !p.error) setCurrentProject((now) => (now && now.id === p.id ? p : now));
      }).catch(() => {});
      return cur;
    });
  }, []);

  // Timezone the user picked in Settings, for absolute History timestamps.
  // "" means auto-detect (browser timezone) — see formatTimestamp() above.
  const [profileTz, setProfileTz] = useState("");
  const refreshProfileTz = useCallback(() => {
    if (signedOut) { setProfileTz(""); return; }
    api.getProfile().then((p) => setProfileTz(p.timezone_pref || "")).catch(() => {});
  }, [signedOut]);
  useEffect(() => { refreshProfileTz(); }, [refreshProfileTz]);

  async function createProjectAndOpen(e) {
    e.preventDefault();
    if (!newProjectName.trim()) return;
    setNewProjectBusy(true); setNewProjectErr(null);
    try {
      const p = await api.createProject(newProjectName.trim(), "");
      refreshProjects();
      setNewProjectOpen(false); setNewProjectName("");
      openProject(p);
    } catch (e2) {
      setNewProjectErr(e2.message || "Could not create project.");
    } finally {
      setNewProjectBusy(false);
    }
  }

  // Create a project from the "file next search under…" picker without
  // entering its workspace — just selects it so the next run gets filed there.
  async function createProjectAndSelect(e) {
    e.preventDefault();
    if (!pickerNewName.trim()) return;
    setPickerBusy(true);
    try {
      const p = await api.createProject(pickerNewName.trim(), "");
      refreshProjects();
      setSelectedProject(p.id);
      setPickerNewOpen(false); setPickerNewName(""); setProjectPickerOpen(false);
    } catch (e2) {
      setError(e2.message || "Could not create project.");
    } finally {
      setPickerBusy(false);
    }
  }

  const [runId, setRunId] = useState(null);
  const [reform, setReform] = useState(null);
  const [papers, setPapers] = useState([]);
  const [approved, setApproved] = useState({});
  const [extractions, setExtractions] = useState([]);
  const [extractStats, setExtractStats] = useState(null);  // full-text coverage (Deep)
  const [synth, setSynth] = useState(null);
  const [sections, setSections] = useState({});
  const [sideModules, setSideModules] = useState(null);
  const [evalRes, setEvalRes] = useState(null);
  const [experimentPlan, setExperimentPlan] = useState(null);
  const [experimentCritique, setExperimentCritique] = useState(null);
  const [experimentIterations, setExperimentIterations] = useState(0);
  const [experimentDebate, setExperimentDebate] = useState({});  // hypothesis index -> [{argument,stance,response}]
  const [experimentKgBridges, setExperimentKgBridges] = useState([]);  // see backend pipeline/knowledge_graph.find_bridge_candidates

  // Hypothesis Agent — its OWN pipeline/table (backend/hypothesis_agent/,
  // core/hypothesis_db.py), separate from Methods' experimentPlan/critique
  // above even though it reuses the same underlying agent classes for now.
  // Read-only display; not persisted into the Sift session's own `data`
  // blob (restoreSession below re-fetches it from /api/hypothesis/runs
  // instead) since it lives in its own table.
  const [hypothesisRun, setHypothesisRun] = useState(null);
  const [hypothesisBusy, setHypothesisBusy] = useState(false);
  // Which companion view is open inside the standalone Hypothesis workspace
  // (Flow B) -- "hypothesis" | "review" | "sources" | "graph". Reset to
  // "hypothesis" every time a project/run is (re)opened via that flow so a
  // stale tab from a previous project never lingers.
  const [hypTab, setHypTab] = useState("hypothesis");
  // Every hypothesis run ever generated for the CURRENT project (not just
  // the current Sift session) -- the Flow-B sidebar's own run history, so
  // switching projects/runs doesn't mean leaving the page (see
  // core/hypothesis_db.py's list_hypothesis_runs, project_id filter).
  const [hypProjectRuns, setHypProjectRuns] = useState([]);
  // When set, the hypothesis-run-loader effect below shows THIS exact run
  // instead of "the latest run for the current session" -- lets the
  // sidebar's "Recent hypotheses" list open any of the last few runs
  // (not just whichever happens to be newest) without them all collapsing
  // to the same result. Cleared whenever a fresh pipeline run starts or a
  // new project/run is opened, so "latest" is the default everywhere else.
  const [pinnedHypRunId, setPinnedHypRunId] = useState(null);
  // Inline "Change project" switcher in the Hypothesis workspace sidebar --
  // a dropdown right there instead of navigating away to the full picker
  // page (which meant Home -> Hypothesis Generation again to get back in).
  const [switchProjectOpen, setSwitchProjectOpen] = useState(false);
  const [switchProjectId, setSwitchProjectId] = useState("");
  const [switchProjectBusy, setSwitchProjectBusy] = useState(false);
  const [switchProjectErr, setSwitchProjectErr] = useState(null);
  const [hypothesisError, setHypothesisError] = useState(null);
  // Live progress for the Hypothesis pipeline's own rail (HypothesisPipelineRail) —
  // hypothesisStage is the stage currently in flight ("fetch"|"designer"|"critic"),
  // hypothesisStageDone marks which stages have finished this run.
  const [hypothesisStage, setHypothesisStage] = useState(null);
  const [hypothesisStageDone, setHypothesisStageDone] = useState({});
  // Sub-stage detail for the two slowest stages (critic: one big scoring
  // call; ranking: matches run one at a time) — see HypothesisPipelineRail's
  // CriticLiveDetail/RankingLiveDetail and pipeline.py's on_progress
  // docstring for exactly what each event carries.
  const [hypothesisLive, setHypothesisLive] = useState({});
  // User-supplied-results check (agents/hypothesis_results_check.py) — the
  // human-in-the-loop counterpart to the automatic plausibility check.
  // Separate busy/error from the main pipeline run since this is a small,
  // independent action a person can take against an already-saved run.
  const [resultsCheckBusy, setResultsCheckBusy] = useState(false);
  const [resultsCheckError, setResultsCheckError] = useState(null);
  // Argument/dispute flow (hypothesis_agent_architecture.md §6, v1: Meta-
  // Review dispute only) — separate busy/error, same reasoning as above.
  const [disputeBusy, setDisputeBusy] = useState(false);
  const [disputeError, setDisputeError] = useState(null);
  // Closing the loop (§7): re-verify an applied refinement against the
  // current champion/runner-up. Separate busy/error, same reasoning again.
  const [reverifyBusy, setReverifyBusy] = useState(false);
  const [reverifyError, setReverifyError] = useState(null);

  const [tab, setTab] = useState("review");
  const [prevTab, setPrevTab] = useState("review"); // Studio opens full-screen — Back returns here
  const reviewRef = useRef(null);
  const isDone = stage === "done";

  // Editable Sources state (post-synthesis): which papers are included, and
  // whether the downstream analysis (synth/critique/graph/data/draft) is stale.
  const [included, setIncluded] = useState({}); // idx -> bool
  const [analysisStale, setAnalysisStale] = useState(false);

  // Live progress messages during search
  const [progressMsgs, setProgressMsgs] = useState([]);

  // Session list from backend (no LLM) + delete-confirm state
  const [sessions, setSessions] = useState([]);
  const [confirmId, setConfirmId] = useState(null);
  const [fileMenuId, setFileMenuId] = useState(null); // which History row's "add to project" popover is open
  const [historyOpen, setHistoryOpen] = useState(false); // full-size History overlay (HistoryView)
  const [projectTabOpen, setProjectTabOpen] = useState(false); // Project drop-down under the top tab
  const [fileMenuNewOpen, setFileMenuNewOpen] = useState(false);
  const [fileMenuNewName, setFileMenuNewName] = useState("");
  const [fileMenuBusy, setFileMenuBusy] = useState(false);

  // History is per-user: skip the fetch entirely while signed out.
  const refreshSessions = useCallback(() => {
    if (signedOut) { setSessions([]); return; }
    api.listSessions()
      .then((d) => setSessions(Array.isArray(d) ? d : []))
      .catch(() => {});
  }, [signedOut]);

  useEffect(() => { refreshSessions(); }, [refreshSessions]);

  // Which model each pipeline stage runs on (per-purpose routing), for the rail.
  const [pipelineModels, setPipelineModels] = useState(null);
  useEffect(() => {
    api.pipelineModels(model, mode).then(setPipelineModels).catch(() => {});
  }, [model, mode]);
  useEffect(() => {
    api.getModes().then((r) => setModes(r.modes || [])).catch(() => {});
  }, []);

  // Load a Hypothesis Agent run for this Sift session, if any — its own
  // table (core/hypothesis_db.py), so it isn't in the session's own `data`
  // blob and has to be fetched separately whenever the active run changes
  // (fresh run, restored session, etc). Normally shows the LATEST run for
  // the session; when pinnedHypRunId is set (the sidebar's "Recent
  // hypotheses" list), shows that exact run instead, so opening an older
  // one doesn't just collapse back to the newest.
  useEffect(() => {
    if (!runId || !isDone) { setHypothesisRun(null); setHypothesisStageDone({}); return; }
    // Don't clobber a live run's rail with a stale saved snapshot — this
    // effect can re-fire (e.g. a re-render triggered by something else
    // touching runId/isDone) while runHypothesisPipeline() is still
    // streaming, and overwriting hypothesisStageDone mid-run is what caused
    // the rail to show a stale "Novelty check" spinner even after a NEWER
    // run's result had already rendered (the two writers were racing on the
    // same state with no ordering guarantee). runHypothesisPipeline()
    // reloads this same data itself once it finishes, via the "done" event.
    if (hypothesisBusy) return;
    let cancelled = false;
    const chosen = pinnedHypRunId
      ? api.getHypothesisRun(pinnedHypRunId)
      : api.listHypothesisRuns(runId).then((r) => {
          const latest = (r.runs || [])[0];
          return latest ? api.getHypothesisRun(latest.id) : null;
        });
    chosen
      .then((full) => {
        if (cancelled) return;
        if (!full) { setHypothesisRun(null); setHypothesisStageDone({}); return; }
        setHypothesisRun(full);
        // A previously-saved run: show its rail as complete for whatever
        // stages it actually reached — novelty/ranking/meta_review only
        // ran if the Designer produced hypotheses to check (see pipeline.py).
        const d = full?.data || {};
        setHypothesisStageDone({
          fetch: true, designer: true, critic: true, refine: !!d.refinement,
          novelty: !!(d.novelty_checks && Object.keys(d.novelty_checks).length > 0),
          ranking: !!d.bracket, meta_review: !!d.meta_review,
          plausibility: !!d.plausibility_check,
        });
      })
      .catch(() => { if (!cancelled) { setHypothesisRun(null); setHypothesisStageDone({}); } });
    return () => { cancelled = true; };
  }, [runId, isDone, hypothesisBusy, pinnedHypRunId]);

  // Flow B's own run history: every hypothesis run ever generated for the
  // CURRENT PROJECT (across all its Lit Review sessions), so the Hypothesis
  // workspace's sidebar can offer "switch to a past run" without leaving
  // the page or going back through the picker. Re-fetches whenever the
  // displayed run's id changes (a fresh pipeline run just finished, or the
  // user pinned a different past run) so a brand-new run shows up in the
  // list right away instead of only after leaving and reopening the page.
  useEffect(() => {
    if (view !== "hypothesis-workspace" || !currentProject?.id) { setHypProjectRuns([]); return; }
    let cancelled = false;
    api.listHypothesisRuns(undefined, currentProject.id)
      .then((r) => { if (!cancelled) setHypProjectRuns(r.runs || []); })
      .catch(() => { if (!cancelled) setHypProjectRuns([]); });
    return () => { cancelled = true; };
  }, [view, currentProject?.id, hypothesisRun?.id]);

  async function runHypothesisPipeline() {
    if (!runId) return;
    setHypothesisBusy(true); setHypothesisError(null);
    setHypothesisStage(null); setHypothesisStageDone({}); setHypothesisLive({});
    setPinnedHypRunId(null); // a fresh run always becomes "latest" — never stay pinned to an older one
    try {
      const final = await api.createHypothesisRunStream(runId, apiKey || undefined, model, (e) => {
        if (e.type === "progress") {
          setHypothesisStage(e.stage);
          if (e.status === "done") {
            setHypothesisStageDone((d) => ({ ...d, [e.stage]: true }));
          } else if (e.status === "start") {
            // critic's "start" carries {hypotheses}; ranking's carries
            // {total} — stash the whole event so CriticLiveDetail/
            // RankingLiveDetail can read whichever fields apply.
            setHypothesisLive((d) => ({ ...d, [e.stage]: { ...e } }));
          } else if (e.status === "match_start") {
            setHypothesisLive((d) => ({
              ...d,
              ranking: { ...(d.ranking || {}), current: { a: e.a, b: e.b } },
            }));
          } else if (e.status === "match_done") {
            setHypothesisLive((d) => ({
              ...d,
              ranking: {
                ...(d.ranking || {}),
                current: null,
                matches: [...((d.ranking || {}).matches || []), { a: e.a, b: e.b, winner: e.winner, reason: e.reason }],
              },
            }));
          }
        }
      });
      setHypothesisRun(final.run);
      // Recompute the rail's done-state straight from the final saved data
      // (same derivation the "restore a saved run" effect above uses),
      // rather than trusting only the accumulated per-event flags — this is
      // what actually guarantees the rail can't show a stage as still
      // in-progress once its real result is on screen, regardless of how
      // any individual progress event was raced or dropped in transit.
      const d = final.run?.data || {};
      setHypothesisStageDone({
        fetch: true, designer: true, critic: true, refine: !!d.refinement,
        novelty: !!(d.novelty_checks && Object.keys(d.novelty_checks).length > 0),
        ranking: !!d.bracket, meta_review: !!d.meta_review,
        plausibility: !!d.plausibility_check,
      });
    } catch (e) {
      setHypothesisError(e.message);
    } finally {
      setHypothesisBusy(false);
      setHypothesisStage(null);
    }
  }

  // Checks one hypothesis (usually the champion) against results the
  // researcher actually ran — appends the verdict to the saved run's
  // data.user_validations; never touches the hypothesis text itself. See
  // agents/hypothesis_results_check.py and hypothesis_routes.py's
  // /check-results.
  async function checkHypothesisResults(hypothesisIndex, resultsText) {
    if (!hypothesisRun?.id) return;
    setResultsCheckBusy(true); setResultsCheckError(null);
    try {
      const updated = await api.checkHypothesisResults(
        hypothesisRun.id, hypothesisIndex, resultsText, apiKey || undefined, model,
      );
      setHypothesisRun(updated);
    } catch (e) {
      setResultsCheckError(e.message);
    } finally {
      setResultsCheckBusy(false);
    }
  }

  // Explicit, human-triggered only: swaps a hypothesis's text for one
  // validation's refined_hypothesis. See hypothesis_routes.py's
  // /apply-refinement for why this never happens automatically.
  async function applyHypothesisRefinement(validationId) {
    if (!hypothesisRun?.id) return;
    setResultsCheckBusy(true); setResultsCheckError(null);
    try {
      const updated = await api.applyHypothesisRefinement(hypothesisRun.id, validationId);
      setHypothesisRun(updated);
    } catch (e) {
      setResultsCheckError(e.message);
    } finally {
      setResultsCheckBusy(false);
    }
  }

  // Closing the loop (§7): give an already-applied refinement a real shot
  // at the champion slot — a fresh Critic score plus up to two head-to-head
  // matches against the current champion/runner-up. Only enabled once the
  // refinement is applied (see hypothesis_routes.py's /reverify-refinement).
  async function reverifyHypothesisRefinement(validationId) {
    if (!hypothesisRun?.id) return;
    setReverifyBusy(true); setReverifyError(null);
    try {
      const updated = await api.reverifyHypothesisRefinement(
        hypothesisRun.id, validationId, apiKey || undefined, model,
      );
      setHypothesisRun(updated);
    } catch (e) {
      setReverifyError(e.message);
    } finally {
      setReverifyBusy(false);
    }
  }

  // Argument/dispute flow (§6): argue with the Meta-Review's recommendation
  // itself. Always returns a response; nothing changes until Apply.
  async function disputeMetaReview(objection) {
    if (!hypothesisRun?.id) return;
    setDisputeBusy(true); setDisputeError(null);
    try {
      const updated = await api.disputeMetaReview(
        hypothesisRun.id, objection, apiKey || undefined, model,
      );
      setHypothesisRun(updated);
    } catch (e) {
      setDisputeError(e.message);
    } finally {
      setDisputeBusy(false);
    }
  }

  async function applyHypothesisDispute(disputeId) {
    if (!hypothesisRun?.id) return;
    setDisputeBusy(true); setDisputeError(null);
    try {
      const updated = await api.applyHypothesisDispute(hypothesisRun.id, disputeId);
      setHypothesisRun(updated);
    } catch (e) {
      setDisputeError(e.message);
    } finally {
      setDisputeBusy(false);
    }
  }

  function reset() {
    setRunId(null); setReform(null); setPapers([]); setApproved({});
    setExtractions([]); setExtractStats(null); setSynth(null); setSections({}); setSideModules(null);
    setEvalRes(null); setError(null); setDone({}); setStage("query");
    setExperimentPlan(null); setExperimentCritique(null); setExperimentIterations(0); setExperimentDebate({});
    setExperimentKgBridges([]);
    setHypothesisRun(null); setHypothesisBusy(false); setHypothesisError(null);
    setHypothesisStage(null); setHypothesisStageDone({}); setHypothesisLive({});
    setResultsCheckBusy(false); setResultsCheckError(null);
    setDisputeBusy(false); setDisputeError(null);
    setReverifyBusy(false); setReverifyError(null);
    setTab("review"); setProgressMsgs([]); setNotes({});
    setIncluded({}); setAnalysisStale(false);
  }

  // Leave whatever project you're in (if any) and start a blank, unfiled chat.
  function startNewChat() {
    setCurrentProject(null);
    setSelectedProject("");
    reset();
    setTopic("");
  }

  // A fresh question that STAYS in the open project: clears the run on
  // screen but keeps currentProject/selectedProject, so the next search is
  // filed under the same project (the "+ New" menu inside a project).
  function startNewSearchInProject() {
    reset();
    setTopic("");
    setTab("review");
  }

  // Enter a project's workspace: every new search now files under it
  // (selectedProject), the header shows its name, and we jump straight to
  // its most recently updated run (or, optionally, a specific one) so
  // opening a project always resumes prior work instead of a blank slate.
  // `landOnTab` (optional) -- Flow A of pipeline-wiring-architecture.md: the
  // ProjectsModal "Generate Hypotheses from this" button restores the run
  // like a normal open, but then wants to land on the Hypothesis tab
  // instead of Review/Sources. restoreSession() sets its own tab once the
  // session data resolves (Review or Sources, see below) -- awaiting it
  // here and overriding tab afterward avoids a race where our override
  // would get stomped by restoreSession's own setTab.
  async function openProject(proj, runIdToOpen, landOnTab) {
    setShowProjects(false);
    setCurrentProject(proj);
    setSelectedProject(proj.id);
    const target = runIdToOpen || (proj.runs || [])[0]?.id;
    if (target) {
      await restoreSession(target);
      if (landOnTab) setTab(landOnTab);
    } else {
      reset(); setTopic("");
    }
  }

  function exitProject() {
    setCurrentProject(null);
    setSelectedProject("");
  }

  // Entry point for the sidebar/Home "Hypothesis Generation" action --
  // lands straight in the Hypothesis workspace with its own project
  // selector already open, instead of a separate picker page first
  // (the workspace's "Change project" switcher below does the same
  // project-with-a-completed-review lookup switchHypothesisProject already
  // does, so this just starts blank with that control expanded).
  function openHypothesisWorkspaceBlank() {
    startNewChat();
    setHypTab("hypothesis");
    setPinnedHypRunId(null);
    setSwitchProjectErr(null);
    setSwitchProjectId("");
    setSwitchProjectOpen(true);
    setView("hypothesis-workspace");
  }

  // Sidebar's "Recent hypotheses" list: open one exact past run. If it came
  // from a different Sift session than the one currently loaded, restore
  // that session first (papers/extractions/sections need to match), THEN
  // pin the exact run id -- otherwise the auto-loader effect would just
  // show whatever's "latest" for that session, which isn't necessarily the
  // one that was clicked when a session has more than one hypothesis run.
  async function openHypothesisRunEntry(r) {
    if (busy) return;
    if (r.source_run_id !== runId) {
      await restoreSession(r.source_run_id);
      setHypTab("hypothesis");
    }
    setPinnedHypRunId(r.id);
  }

  // Switch WITHIN the current project to a specific completed review --
  // previously the workspace always silently used whichever review was
  // most recently updated (switchHypothesisProject's `latest` pick below),
  // with no way to deliberately choose a different one of the project's
  // own reviews without leaving the page. Same restoreSession() mechanism
  // the plain Sift sidebar's project run list already uses (App.jsx's
  // main "Project" panel) -- this is that same action, just reachable
  // from inside the Hypothesis workspace too.
  async function switchHypothesisRun(run) {
    if (!run || busy || run.id === runId) return;
    await restoreSession(run.id);
    setHypTab("hypothesis");
    setPinnedHypRunId(null); // new source review -> show ITS latest hypothesis run, not a stale pin
  }

  // The Hypothesis workspace's inline "Change project" switcher (same
  // pick-a-project-with-a-completed-review logic as HypothesisPicker.jsx's
  // own `open()`, just triggered from a dropdown in the sidebar instead of
  // navigating to a separate page).
  async function switchHypothesisProject(projectId) {
    if (!projectId) return;
    setSwitchProjectErr(null);
    setSwitchProjectBusy(true);
    try {
      const full = await api.getProject(projectId);
      const doneRuns = (full.runs || []).filter((r) => r.stage === "done");
      if (doneRuns.length === 0) {
        setSwitchProjectErr(`"${full.name}" doesn't have a completed Literature Review yet.`);
        return;
      }
      const latest = [...doneRuns].sort((a, b) => (b.updated_at || "").localeCompare(a.updated_at || ""))[0];
      await openProject(full, latest.id, "hypothesis");
      setHypTab("hypothesis");
      setPinnedHypRunId(null); // new project -> show ITS latest, not a pin left over from the last one
      setSwitchProjectOpen(false);
    } catch (e) {
      setSwitchProjectErr(e.message || "Couldn't load that project.");
    } finally {
      setSwitchProjectBusy(false);
    }
  }

  async function deleteAllData() {
    const ok = await confirmAsync("Permanently delete all your saved runs? This cannot be undone.",
      { title: "Delete all data?", danger: true, confirmLabel: "Delete everything" });
    if (!ok) return;
    try {
      await api.deleteAllSessions();
      reset(); setTopic("");
      refreshSessions();
    } catch (e) {
      setError({ stage: "Delete data", msg: e.message });
    }
  }

  // Fires once, after Home's search box has set `topic` and switched the
  // shell into "workspace" — kicks off the same runStart() the existing
  // "+ New" flow uses, just triggered from the dashboard Home page instead.
  useEffect(() => {
    if (autoStartTopic && view === "workspace" && topic.trim() && !busy) {
      setAutoStartTopic(false);
      runStart();
    }
  }, [autoStartTopic, view, topic, busy]);

  // Restore a session — zero LLM calls
  async function restoreSession(sessionId) {
    if (busy) return;
    try {
      const s = await api.getSession(sessionId);
      const d = s.data;
      reset();
      setTopic(d.topic || "");
      setRunId(d.runId || null);
      setReform(d.reform || null);
      setPapers(d.papers || []);
      setApproved(d.approved || {});
      if (s.stage === "done") {
        const secs = d.sections || {};
        const hasReview = Object.keys(secs).length > 0;
        setExtractions(d.extractions || []);
        setSynth(d.synth || null);
        setSections(secs);
        setSideModules(d.sideModules || null);
        setNotes(d.notes || {});
        setExperimentPlan(d.experimentPlan || null);
        setExperimentCritique(d.experimentCritique || null);
        setExperimentIterations((d.experimentIterations || []).length);
        setExperimentDebate(d.experimentDebate || {});
        setExperimentKgBridges(d.experimentKgBridges || []);
        const inc = {};
        Object.entries(d.approved || {}).forEach(([k, v]) => { if (v) inc[Number(k)] = true; });
        setIncluded(inc);
        setAnalysisStale(false);
        setDone({ query: true, reformulate: true, search: true, extract: true, synthesize: true, write: hasReview });
        setStage("done");
        setTab(hasReview ? "review" : "sources");
        setTimeout(() => reviewRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
      } else {
        setDone({ query: true, reformulate: true, search: true });
        setStage("filter");
      }
    } catch (e) {
      setError({ stage: "Session restore", msg: e.message });
    }
  }

  async function deleteSession(id) {
    await api.deleteSession(id);
    refreshSessions();
  }

  // File an already-searched History run under a project (existing or new)
  // after the fact — separate from `selectedProject`/`currentProject`, which
  // only apply to runs started FROM INSIDE a project going forward.
  async function fileSessionUnderProject(sessionId, projectId) {
    setFileMenuBusy(true);
    try {
      await api.assignRunProject(sessionId, projectId);
      setFileMenuId(null);
      setFileMenuNewOpen(false);
      setFileMenuNewName("");
      refreshSessions();
      refreshProjects();
      refreshCurrentProject();
    } catch (e) {
      setError({ stage: "File under project", msg: e.message });
    } finally {
      setFileMenuBusy(false);
    }
  }

  async function createProjectAndFile(sessionId, e) {
    e.preventDefault();
    if (!fileMenuNewName.trim()) return;
    setFileMenuBusy(true);
    try {
      const p = await api.createProject(fileMenuNewName.trim(), "");
      await fileSessionUnderProject(sessionId, p.id);
    } catch (e2) {
      setError({ stage: "File under project", msg: e2.message || "Could not create project." });
      setFileMenuBusy(false);
    }
  }

  // What shows in Sources/Review: a paper the user hasn't removed. `included`
  // is the Sources-stage source of truth (set after filtering, toggled by
  // remove/add); before it's populated we fall back to the filter `approved`.
  const approvedList = papers.filter((p) =>
    included[p.idx] !== undefined ? included[p.idx] : approved[p.idx]
  );
  // Keep the SEARCH-RELEVANCE order the user approved — stable from Paper Filter
  // through Sources and matching the Writer's citation numbering (backend orders
  // citations the same way). The synthesizer's scores still show in the Ranking
  // module and the comparison-table Rank column; they no longer reshuffle this list.
  const citeOrder = approvedList;
  const citeNum = {};
  citeOrder.forEach((p, i) => (citeNum[p.idx] = i + 1));

  async function runStart() {
    // Gated action: anyone can browse, but running the pipeline needs an account.
    if (!(await ensureAuth())) return;

    setBusy(true); setError(null); setPlanNotice(null); setStage("reformulate"); setProgressMsgs([]);
    try {
      const res = await api.createRunStream(
        topic.trim(),
        apiKey || undefined,
        model,
        mode,
        (event) => {
          if (event.type === "progress") {
            // The reformulator's output arrives before the slow search — show
            // the "Understanding your question" card as soon as it does.
            if (event.reform) setReform(event.reform);
            setProgressMsgs((prev) => {
              const last = prev[prev.length - 1];
              if (last?.message === event.message) return prev;
              return [...prev, event];
            });
            if (event.step === "reformulate") setStage("reformulate");
            if (event.step === "search") setStage("search");
          }
        },
        selectedProject || undefined
      );
      setRunId(res.run_id);
      setReform(res.reform);
      if (res.plan_notice) setPlanNotice(res.plan_notice);
      const p = res.papers || [];
      setPapers(p);
      const ap = {}; p.forEach((x) => (ap[x.idx] = true));
      setApproved(ap);
      setDone((d) => ({ ...d, query: true, reformulate: true, search: true }));
      setStage("filter");
      refreshSessions();
      if (selectedProject) { refreshProjects(); refreshCurrentProject(); }
    } catch (e) {
      setError({ stage: "Query Reformulator / Academic Search", msg: e.message, retry: runStart });
      setStage("query");
    } finally {
      setBusy(false);
    }
  }

  // Studio-only entry: skip search entirely, land on Sources with an empty
  // paper list ready for "+ Add paper" > "Or upload a file" — once at least
  // one document is uploaded, Studio (and everything else — Update analysis,
  // Generate literature review — all still work, since this is just a run
  // with papers=[] rather than a different kind of run).
  async function startAnalyzeDocs() {
    if (!(await ensureAuth())) return;
    setBusy(true); setError(null);
    try {
      const res = await api.createBlankRun(topic.trim() || undefined, selectedProject || undefined);
      reset();
      setRunId(res.run_id);
      setTopic(res.topic || "");
      setStage("done");
      setDone({ query: true, reformulate: true, search: true, extract: true, synthesize: true });
      setTab("sources");
      refreshSessions();
      if (selectedProject) { refreshProjects(); refreshCurrentProject(); }
    } catch (e) {
      setError({ stage: "Analyze your own documents", msg: e.message, retry: startAnalyzeDocs });
    } finally {
      setBusy(false);
    }
  }

  async function runApprove() {
    const approvedIndices = Object.entries(approved).filter(([, v]) => v).map(([k]) => Number(k));
    if (approvedIndices.length < 2) {
      setError({ stage: "Paper Filter", msg: "Approve at least 2 papers to synthesize a review." });
      return;
    }
    setBusy(true); setError(null); setProgressMsgs([]);
    try {
      await api.filterPapers(runId, approvedIndices);
      setStage("extract");
      // Streamed: rows tick in as each batch of papers is read, then the
      // synthesizer runs — instead of one blank "Extracting…" spinner.
      const doneEv = await api.synthesizeStream(
        runId, apiKey || undefined, model, notes,
        (event) => {
          if (event.type === "progress") {
            setProgressMsgs((prev) => {
              const last = prev[prev.length - 1];
              if (last?.message === event.message) return prev;
              return [...prev, event];
            });
            if (event.step === "synthesize") setStage("synthesize");
          }
        }
      );
      setExtractions(doneEv.extractions);
      setExtractStats(doneEv.extract_stats || null);
      setSynth(doneEv.synthesis);
      setSideModules(doneEv.side_modules);
      // Everything approved at the filter stage starts "included" on the Sources page.
      const inc = {}; approvedIndices.forEach((i) => (inc[i] = true));
      setIncluded(inc);
      setAnalysisStale(false);
      setDone((d) => ({ ...d, extract: true, synthesize: true }));
      setStage("done");
      setTab("sources");
      refreshSessions();
      setTimeout(() => reviewRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
    } catch (e) {
      setError({ stage: "Reader & Extractor / Critic & Synthesizer", msg: e.message, retry: runApprove });
    } finally {
      setBusy(false);
    }
  }

  // ── Sources page editing ────────────────────────────────────────────
  function removeSources(indices) {
    setIncluded((prev) => {
      const n = { ...prev };
      indices.forEach((i) => { n[i] = false; });
      return n;
    });
    setAnalysisStale(true);
  }

  async function addPaperToSources(paper) {
    try {
      const res = await api.addPaper(runId, paper, apiKey || undefined, model, notes);
      const np = { ...res.paper, added: true };
      setPapers((prev) => [...prev, np]);
      if (res.extraction) {
        setExtractions((prev) => [...prev.filter((e) => e.idx !== np.idx), res.extraction]);
      }
      setIncluded((prev) => ({ ...prev, [np.idx]: true }));
      setAnalysisStale(true);
      refreshSessions();
      return np;
    } catch (e) {
      // Same reconciliation as uploadPaperToSources below — a dropped
      // connection or a retry-after-drop can both leave a paper actually
      // persisted server-side while this tab still thinks it's missing.
      const msg = String(e.message || "").toLowerCase();
      if (msg.includes("failed to fetch") || msg.includes("already in your sources")) {
        try {
          const fresh = await api.getRunState(runId);
          const knownIdx = new Set(papers.map((p) => p.idx));
          const arrived = (fresh.papers || []).find((p) => !knownIdx.has(p.idx));
          if (arrived) {
            setPapers(fresh.papers || []);
            setExtractions(fresh.extractions || []);
            setIncluded((prev) => ({ ...prev, [arrived.idx]: true }));
            setAnalysisStale(true);
            refreshSessions();
            return arrived;
          }
        } catch { /* reconciliation failed too — fall through to the real error */ }
      }
      throw e;
    }
  }

  // Same as addPaperToSources, but for a locally-uploaded PDF/DOCX instead of
  // a resolved search result — extraction happens server-side in one call.
  async function uploadPaperToSources(file, titleOverride) {
    const res = await api.uploadPaper(runId, file, apiKey || undefined, model, notes, titleOverride);
    const np = { ...res.paper, added: true };
    setPapers((prev) => [...prev, np]);
    if (res.extraction) {
      setExtractions((prev) => [...prev.filter((e) => e.idx !== np.idx), res.extraction]);
    }
    setIncluded((prev) => ({ ...prev, [np.idx]: true }));
    setAnalysisStale(true);
    refreshSessions();
    return np;
  }

  async function reanalyzeSources() {
    const includedIndices = papers.filter((p) => included[p.idx]).map((p) => p.idx);
    if (includedIndices.length < 1) {
      setError({ stage: "Update analysis", msg: "Include at least one source." });
      return;
    }
    setBusy(true); setError(null);
    try {
      const r = await api.reanalyze(runId, includedIndices, apiKey || undefined, model, notes);
      setExtractions(r.extractions);
      setSynth(r.synthesis);
      setSideModules(r.side_modules);
      setSections(r.sections || {});
      setDone((d) => ({ ...d, write: Object.keys(r.sections || {}).length > 0 }));
      setAnalysisStale(false);
      refreshSessions();
    } catch (e) {
      setError({ stage: "Update analysis", msg: e.message, retry: reanalyzeSources });
    } finally {
      setBusy(false);
    }
  }

  // generate the written cited review (Writer agent) on demand.
  async function runWrite() {
    // switch to the "write" stage so the Writer Agent progress card shows while
    // the review is being drafted (otherwise the pipeline is already "done" and
    // no status is visible during generation).
    setBusy(true); setError(null); setStage("write");
    try {
      const writeRes = await api.write(runId, apiKey || undefined, model, notes, mode);
      setSections(writeRes.sections);
      if (writeRes.side_modules) setSideModules(writeRes.side_modules);
      setDone((d) => ({ ...d, write: true }));
      setTab("review");
      refreshSessions();
    } catch (e) {
      setError({ stage: "Writer Agent", msg: e.message, retry: runWrite });
    } finally {
      setBusy(false); setStage("done");
    }
  }

  async function runEvaluate() {
    setBusy(true); setError(null);
    try {
      const res = await api.evaluate(runId, apiKey || undefined, model);
      setEvalRes(res.eval_result);
    } catch (e) {
      setError({ stage: "Evaluator", msg: e.message, retry: runEvaluate });
    } finally {
      setBusy(false);
    }
  }

  async function runDesignExperiments() {
    setBusy(true); setError(null);
    try {
      const res = await api.designExperiments(runId, apiKey || undefined, model);
      setExperimentPlan(res.experiment_plan);
      setExperimentCritique(null);
      setExperimentIterations(0);
      setExperimentKgBridges(res.experiment_kg_bridges || []);
    } catch (e) {
      setError({ stage: "Experiment Designer", msg: e.message, retry: runDesignExperiments });
    } finally {
      setBusy(false);
    }
  }

  // Recursive self-improvement pass: critique the current plan and revise
  // any weak hypothesis, up to a couple of rounds server-side. Safe to call
  // with no existing plan — the backend designs one first in that case.
  async function runRefineExperiments() {
    setBusy(true); setError(null);
    try {
      const res = await api.refineExperiments(runId, apiKey || undefined, model);
      setExperimentPlan(res.experiment_plan);
      setExperimentCritique(res.experiment_critique);
      setExperimentIterations(res.iterations);
      setExperimentKgBridges(res.experiment_kg_bridges || []);
    } catch (e) {
      setError({ stage: "Hypothesis Refinement", msg: e.message, retry: runRefineExperiments });
    } finally {
      setBusy(false);
    }
  }

  // Direct edit — the user overrules/tweaks a hypothesis by hand. Instant,
  // no LLM call, so no busy/spinner state.
  async function updateHypothesis(index, edits) {
    try {
      const res = await api.updateHypothesis(runId, index, edits);
      setExperimentPlan((plan) => {
        if (!plan) return plan;
        const hypotheses = [...(plan.hypotheses || [])];
        hypotheses[index] = res.hypothesis;
        return { ...plan, hypotheses };
      });
      setExperimentCritique((c) =>
        c ? { ...c, critiques: (c.critiques || []).filter((x) => x.index !== index) } : c
      );
    } catch (e) {
      setError({ stage: "Hypothesis Edit", msg: e.message });
    }
  }

  // Argue with one hypothesis — the designer revises it or defends it with a
  // specific counter-reason (never just concedes to be agreeable). Doesn't
  // touch the hypothesis itself: "both agree" means the human decides
  // whether to apply the proposed revision, via acceptRevision() below.
  async function disputeHypothesis(index, argument) {
    setBusy(true); setError(null);
    try {
      const res = await api.disputeHypothesis(runId, index, argument, apiKey || undefined, model);
      setExperimentDebate((d) => ({ ...d, [index]: res.history }));
      return res;
    } catch (e) {
      setError({ stage: "Hypothesis Dispute", msg: e.message });
      return null;
    } finally {
      setBusy(false);
    }
  }

  // The human agrees with a proposed revision from a dispute round — apply
  // it via the same instant, no-LLM-call path as a manual edit.
  function acceptRevision(index, proposed) {
    return updateHypothesis(index, proposed);
  }

  async function exportExperiments(fmt) {
    try {
      await api.downloadExperimentsExport(runId, fmt);
    } catch (e) {
      setError({ stage: "Methods Export", msg: e.message });
    }
  }

  function download(filename, text, type = "text/plain;charset=utf-8") {
    const blob = new Blob([text], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  }

  function exportShortlist(fmt) {
    const extByIdx = {};
    (extractions || []).forEach((e) => (extByIdx[e.idx] = e));
    const rows = citeOrder.map((p, i) => ({
      n: i + 1, ...p, ...(extByIdx[p.idx] || {}), note: notes[p.idx] || "",
    }));
    const slug = (topic || "shortlist").replace(/[^\w]+/g, "-").slice(0, 40).replace(/^-|-$/g, "") || "shortlist";

    if (fmt === "md") {
      let md = `# Literature shortlist — ${topic}\n\n_${rows.length} papers_\n\n`;
      rows.forEach((r) => {
        md += `## [${r.n}] ${r.title}\n`;
        md += `${r.authors || "—"} · ${r.year || "—"} · ${r.venue || "preprint"}\n`;
        if (r.url) md += `${r.url}\n`;
        md += "\n";
        if (r.method && r.method !== "n/a") md += `- **Method:** ${r.method}\n`;
        if (r.finding && r.finding !== "n/a") md += `- **Finding:** ${r.finding}\n`;
        if (r.metrics && r.metrics !== "n/a") md += `- **Metrics:** ${r.metrics}\n`;
        if (r.contribution && r.contribution !== "n/a") md += `- **Contribution:** ${r.contribution}\n`;
        if (r.note) md += `- **My notes:** ${r.note}\n`;
        md += "\n";
      });
      download(`${slug}.md`, md, "text/markdown;charset=utf-8");
    } else if (fmt === "bib") {
      const bib = rows.map((r) => {
        const first = (r.authors || "unknown").split(/[ ,]/)[0].toLowerCase().replace(/[^a-z]/g, "") || "ref";
        const key = `${first}${r.year || ""}_${r.idx}`;
        return `@article{${key},
  title   = {${r.title || ""}},
  author  = {${r.authors || ""}},
  year    = {${r.year || ""}},
  journal = {${r.venue || ""}},
  url     = {${r.url || ""}},
  note    = {${(r.note || "").replace(/[{}]/g, "")}}
}`;
      }).join("\n\n");
      download(`${slug}.bib`, bib, "application/x-bibtex;charset=utf-8");
    }
  }

  const projectNameOf = (id) => projects.find((p) => p.id === id)?.name || "";

  // Signed-out visitors see the public landing page; the tools app is gated
  // behind login. (All hooks above run unconditionally, so this early return
  // is safe.)
  // Still checking for a saved sign-in: show a blank page for that instant
  // rather than the landing page, which would flash before the workspace.
  if (signedOut && !authReady) return <div style={{ minHeight: "100vh", background: "#fff" }} />;
  if (signedOut) return <LandingPage />;

  return (
    <div className="sm-root">
      {confirmModal}

      {/* Studio takes the full window (no dialog chrome, no backdrop) —
          it's a whole workspace, not a small side tool. Back returns to
          whatever tab was showing before Studio was opened. The panel stays
          mounted once a run is loaded and is only hidden (not unmounted)
          while another tab is active, so in-progress work here — which
          sources are selected, an unsaved chat draft, a generated-but-not-
          downloaded artifact — survives leaving and coming back, instead of
          resetting every time Studio reopens. */}
      {isDone && (
        <div
          style={{
            position: "fixed", inset: 0, zIndex: 800,
            display: tab === "studio" ? "flex" : "none",
            flexDirection: "column",
            background: "var(--bg, #f4f5f9)",
          }}
        >
          <div
            style={{
              display: "flex", alignItems: "center", gap: 10,
              padding: "12px 18px", borderBottom: "1px solid var(--line)",
              background: "var(--card, #fff)", flex: "0 0 auto",
            }}
          >
            <button className="btn ghost sm" onClick={() => setTab(prevTab)}>
              <ArrowLeft size={14} /> Back
            </button>
            <span style={{ fontWeight: 700, fontSize: 14.5 }}>Studio</span>
            <span className="muted tiny">Chat, report, deck & briefing across your sources</span>
          </div>
          <div style={{ flex: "1 1 auto", overflow: "auto", padding: 18 }}>
            <StudioView runId={runId} papers={citeOrder} extractions={extractions} apiKey={apiKey} />
          </div>
        </div>
      )}

      {accountTab && (
        <ProfileModal user={session?.user} tab={accountTab}
          onClose={() => { setAccountTab(null); refreshProfileTz(); }} />
      )}

      {showProjects && (
        <ProjectsModal
          initialMode={projectsInitialMode}
          onClose={() => { setShowProjects(false); setProjectsInitialMode(null); refreshProjects(); }}
          onOpenRun={(id, proj) => { openProject(proj, id); setView("workspace"); }}
          onGenerateHypotheses={(id, proj) => { openProject(proj, id, "hypothesis"); setHypTab("hypothesis"); setPinnedHypRunId(null); setSwitchProjectOpen(false); setView("hypothesis-workspace"); }}
          onOpenProject={(proj) => { openProject(proj); setView("workspace"); }}
        />
      )}
      <div style={{ display: "flex" }}>
        {view === "home" && (
          <Sidebar
            activeView={view}
            onNewProject={() => { setProjectsInitialMode("create"); setShowProjects(true); }}
            onGoHome={() => setView("home")}
            onLiteratureReview={() => setView("workspace")}
            onHypothesisGeneration={openHypothesisWorkspaceBlank}
            onPhysicalAI={() => setView("physical-ai")}
            onDataAnalysis={(which) => { setDataAnalysisWhich(which); setView("data-analysis"); }}
            onOpenBilling={() => setView("billing")}
            onOpenProfile={() => setAccountTab("profile")}
            onOpenSettings={() => setAccountTab("settings")}
            onDeleteAllData={deleteAllData}
          />
        )}
        <div style={{ flex: 1, minWidth: 0 }}>
        {view === "home" && (
          <HomePage
            userName={session?.user?.user_metadata?.full_name || session?.user?.email || ""}
            projects={projects}
            onStartTopic={(t) => { startNewChat(); setTopic(t); setAutoStartTopic(true); setView("workspace"); }}
            onOpenLitReview={() => setView("workspace")}
            onOpenHypothesisPicker={openHypothesisWorkspaceBlank}
            onOpenDataAnalysis={(which) => { setDataAnalysisWhich(which); setView("data-analysis"); }}
            onOpenProject={async (proj) => { await openProject(proj); setView("workspace"); }}
            onStartLiteReview={(t) => { startNewChat(); setMode("lite"); setTopic(t); setAutoStartTopic(true); setView("workspace"); }}
          />
        )}
        {view === "physical-ai" && <PhysicalAIView onBack={() => setView("home")} />}
        {view === "data-analysis" && (
          dataAnalysisWhich === "timeseries" ? (
            <DataAnalysisPlaceholder which={dataAnalysisWhich} onBack={() => setView("home")} />
          ) : (
            <DataAnalysisAgentView
              which={dataAnalysisWhich}
              projectId={currentProject?.id}
              projects={projects}
              onBack={() => setView("home")}
            />
          )
        )}
        {view === "hypothesis-workspace" && (
          <div className="sm-wrap wide">
            <div className="sm-head" style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 20 }}>
              <div>
                <button
                  type="button" onClick={() => setView("home")}
                  style={{
                    display: "flex", alignItems: "center", gap: 6, background: "none", border: "none",
                    color: "var(--muted)", fontSize: 12.5, fontWeight: 600, cursor: "pointer",
                    padding: 0, marginBottom: 10, fontFamily: "inherit",
                  }}
                >
                  <ArrowLeft size={13} /> Home
                </button>
                <div className="eyebrow" style={{ marginBottom: 8 }}>Hypothesis workspace</div>
                <div className="sm-title">
                  <b>Hypothesis Agent</b>
                  {currentProject && (
                    <span style={{ color: "var(--muted)", fontWeight: 400 }}>
                      {" "}/ {currentProject.name}
                    </span>
                  )}
                </div>
                <div className="sm-gloss">
                  {currentProject
                    ? "Reads this project's Literature Review findings and generates, critiques, and ranks hypotheses."
                    : "Pick a project with a completed Literature Review on the left to generate, critique, and rank hypotheses from its findings."}
                </div>
                {/* Which of the project's (possibly several) completed
                    reviews is actually feeding this run -- previously only
                    the project name showed here, so with >1 review in a
                    project there was no way to tell which one was in use
                    without opening the project modal and comparing
                    timestamps. Mirrors `topic`, the same state the search
                    box itself uses, kept in sync by restoreSession(). */}
                {currentProject && topic && (
                  <div style={{ fontSize: 12.5, color: "var(--muted)", marginTop: 6 }}>
                    Based on: <span style={{ color: "var(--txt)", fontWeight: 600 }}>{topic}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="grid3">
              {/* LEFT: a small Tools list scoped to what's useful while
                  reading/critiquing hypotheses (see HYP_TOOLS above), plus
                  a way to switch project/run without leaving this page --
                  the picker (Home > Hypothesis Generation) is one way in,
                  but "back" from here shouldn't have to go all the way home
                  just to pick a different project. */}
              <div className="lcol">
                <div className="panel">
                  <div className="panel-head-label" style={{ marginBottom: 10 }}>Project</div>
                  {currentProject ? (
                    <div style={{ fontSize: 13, fontWeight: 700, color: "var(--txt)", marginBottom: 8 }}>
                      {currentProject.name}
                    </div>
                  ) : (
                    <div className="muted tiny" style={{ marginBottom: 8 }}>No project open yet. Pick one below.</div>
                  )}

                  {!switchProjectOpen ? (
                    <button
                      type="button"
                      className="btn ghost sm"
                      style={{ width: "100%", justifyContent: "center" }}
                      onClick={() => {
                        setSwitchProjectErr(null);
                        setSwitchProjectId("");
                        setSwitchProjectOpen(true);
                      }}
                    >
                      Change project
                    </button>
                  ) : (
                    <div>
                      <select
                        value={switchProjectId}
                        onChange={(e) => setSwitchProjectId(e.target.value)}
                        disabled={switchProjectBusy}
                        style={{
                          width: "100%", border: "1px solid var(--line, #e4e7ef)", borderRadius: 8,
                          padding: "7px 8px", fontSize: 12.5, fontFamily: "inherit", marginBottom: 6,
                          background: "var(--panel, #fff)", color: "var(--txt, #1c2128)",
                        }}
                      >
                        <option value="">Pick a project…</option>
                        {(projects || [])
                          .filter((p) => (p.run_count || 0) > 0 && p.id !== currentProject?.id)
                          .map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name} — {p.run_count} run{p.run_count === 1 ? "" : "s"}
                            </option>
                          ))}
                      </select>
                      {switchProjectErr && (
                        <div style={{ color: "#c0392b", fontSize: 11.5, marginBottom: 6 }}>{switchProjectErr}</div>
                      )}
                      <div style={{ display: "flex", gap: 6 }}>
                        <button
                          type="button"
                          className="btn sm"
                          style={{ flex: 1, justifyContent: "center" }}
                          disabled={!switchProjectId || switchProjectBusy}
                          onClick={() => switchHypothesisProject(switchProjectId)}
                        >
                          {switchProjectBusy ? "Opening…" : "Open"}
                        </button>
                        <button
                          type="button"
                          className="btn ghost sm"
                          onClick={() => { setSwitchProjectOpen(false); setSwitchProjectErr(null); }}
                          disabled={switchProjectBusy}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="panel">
                  <div className="panel-head-label" style={{ marginBottom: 12 }}>Tools</div>
                  {HYP_TOOLS.map(([k, Ic, lab]) => (
                    <button
                      key={k}
                      className={"tool-item" + (hypTab === k ? " on" : "")}
                      onClick={() => setHypTab(k)}
                    >
                      <Ic size={14} /> {lab}
                    </button>
                  ))}
                </div>

                {/* Publish: its own card, like Project -- the step after the
                    hypotheses, not one more view of them. */}
                <div className="panel">
                  <div className="panel-head-label" style={{ marginBottom: 10 }}>Publish</div>
                  <div className="muted tiny" style={{ lineHeight: 1.5, marginBottom: 10 }}>
                    Write this work up as a paper in a journal's own format.
                  </div>
                  <button
                    className={"tool-item" + (hypTab === "publish" ? " on" : "")}
                    style={{ marginBottom: 0 }}
                    disabled={!runId || !isDone}
                    title={!runId || !isDone ? "Open a project with a completed Literature Review first" : ""}
                    onClick={() => setHypTab("publish")}
                  >
                    <PenTool size={14} /> Write a paper
                  </button>
                </div>

                {/* Which completed review, of possibly several in this
                    project, is the source for hypothesis generation --
                    previously the project always silently used whichever
                    review was most recently updated with no way to pick a
                    different one. Only shown when there's more than one
                    completed review to actually choose between. */}
                {currentProject && (currentProject.runs || []).filter((r) => r.stage === "done").length > 1 && (
                  <div className="panel">
                    <div className="panel-head-label" style={{ marginBottom: 10 }}>
                      Literature review used
                    </div>
                    <div style={{ ...H.scroll, maxHeight: 200 }}>
                      {currentProject.runs
                        .filter((r) => r.stage === "done")
                        .map((r) => (
                          <div
                            key={r.id}
                            style={{ ...H.item, ...(r.id === runId ? H.itemActive : {}) }}
                            onClick={() => switchHypothesisRun(r)}
                            title={r.topic}
                          >
                            <div style={H.itemTopic}>{r.topic || "Untitled review"}</div>
                            <div style={H.meta}>
                              {r.id === runId
                                ? <span style={{ ...H.badge, ...H.badgeDone }}>in use</span>
                                : <span>{r.paper_count}p</span>}
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                {hypProjectRuns.length > 0 && (
                  <div className="panel">
                    <div className="panel-head-label" style={{ marginBottom: 10 }}>
                      Recent hypotheses
                    </div>
                    {hypProjectRuns.slice(0, 3).map((r) => {
                      const isShown = pinnedHypRunId ? r.id === pinnedHypRunId : r.id === hypProjectRuns[0]?.id && r.source_run_id === runId;
                      return (
                        <div
                          key={r.id}
                          style={{ ...H.item, ...(isShown ? H.itemActive : {}) }}
                          onClick={() => openHypothesisRunEntry(r)}
                          title={r.source_topic}
                        >
                          <div style={H.itemTopic}>{r.source_topic || "Untitled review"}</div>
                          <div style={H.meta}>
                            <span>{relativeTime(r.created_at)}</span>
                            {r.staleness?.stale && (
                              <>
                                <span style={H.dot}>·</span>
                                <span style={{ color: "#b8860b" }}>stale</span>
                              </>
                            )}
                          </div>
                        </div>
                      );
                    })}
                    {hypProjectRuns.length > 3 && (
                      <div style={{ fontSize: 11, color: "var(--muted2, #98a0af)", padding: "6px 2px 0" }}>
                        +{hypProjectRuns.length - 3} older, not shown
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* CENTER: swaps by hypTab -- same components/props Sift's own
                  workspace tabs use (same session data), just reached from
                  the standalone Hypothesis entry point instead. */}
              <div>
                <div className="card">
                  {hypTab === "hypothesis" && (
                    <HypothesisAgentPanel
                      runId={runId}
                      busy={hypothesisBusy}
                      result={hypothesisRun}
                      error={hypothesisError}
                      onRun={runHypothesisPipeline}
                      papers={papers}
                      extractions={extractions}
                      onCheckResults={checkHypothesisResults}
                      onApplyRefinement={applyHypothesisRefinement}
                      resultsCheckBusy={resultsCheckBusy}
                      resultsCheckError={resultsCheckError}
                      onReverifyRefinement={reverifyHypothesisRefinement}
                      reverifyBusy={reverifyBusy}
                      reverifyError={reverifyError}
                      onDisputeMetaReview={disputeMetaReview}
                      onApplyDispute={applyHypothesisDispute}
                      disputeBusy={disputeBusy}
                      disputeError={disputeError}
                    />
                  )}
                  {hypTab === "publish" && (
                    <PublishPanel runId={runId} hypRunId={hypothesisRun?.id} apiKey={apiKey} model={model} topic={topic} />
                  )}
                  {hypTab === "review" && (
                    Object.keys(sections || {}).length > 0
                      ? <>
                          <ExportBar runId={runId} onError={(m) => setError({ stage: "Export", msg: m })} />
                          <ReviewView topic={topic} sections={sections} citeOrder={citeOrder} />
                        </>
                      : (
                        <div style={{ textAlign: "center", padding: "28px 16px" }}>
                          <h3 style={{ margin: "0 0 8px", fontSize: 16 }}>No written review yet</h3>
                          <div className="muted tiny" style={{ maxWidth: 460, margin: "0 auto", lineHeight: 1.6 }}>
                            This project's Literature Review hasn't generated a written review yet —
                            open it from Literature Review to write one.
                          </div>
                        </div>
                      )
                  )}
                  {hypTab === "sources" && (
                    <SourcesView
                      citeOrder={citeOrder} extractions={extractions} ranked={synth?.ranked}
                      extractStats={extractStats} runId={runId} apiKey={apiKey} model={model}
                      papers={papers} included={included} scope={reform?.scope}
                      analysisStale={analysisStale} busy={busy}
                      onRemove={removeSources} onAdd={addPaperToSources}
                      onUpload={uploadPaperToSources}
                      onReanalyze={reanalyzeSources} onGenerate={runWrite}
                      hasReview={Object.keys(sections || {}).length > 0}
                    />
                  )}
                  {hypTab === "graph" && (
                    <KnowledgeGraphView concepts={sideModules?.knowledge_graph} citeNum={citeNum} papers={citeOrder} />
                  )}
                </div>
              </div>

              <div className="rcol">
                <HypothesisPipelineRail
                  stage={hypothesisStage}
                  busy={hypothesisBusy}
                  done={hypothesisStageDone}
                  live={hypothesisLive}
                />
              </div>
            </div>
          </div>
        )}
        {view === "billing" && (
          <div style={{ maxWidth: 1100, margin: "0 auto", padding: "24px 32px 80px" }}>
            <button
              type="button" onClick={() => setView("home")}
              style={{
                display: "flex", alignItems: "center", gap: 6, background: "none", border: "none",
                color: "var(--muted)", fontSize: 12.5, fontWeight: 600, cursor: "pointer",
                padding: 0, marginBottom: 14, fontFamily: "inherit",
              }}
            >
              <ArrowLeft size={13} /> Home
            </button>
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 20, fontWeight: 700, marginBottom: 4 }}>
              <Coins size={19} /> Account and Billing
            </div>
            <div className="muted tiny" style={{ marginBottom: 20 }}>
              Your plan and free-trial credits are below, followed by your actual usage and
              cost so far across every project.
            </div>
            <PlanPanel />
            <div className="card">
              <UsageView runId={null} />
            </div>
          </div>
        )}
        {view === "workspace" && (
      <div className="sm-wrap wide">
        <div className="sm-head" style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 20 }}>
          <div>
            <button
              type="button" onClick={() => setView("home")}
              style={{
                display: "flex", alignItems: "center", gap: 6, background: "none", border: "none",
                color: "var(--muted)", fontSize: 12.5, fontWeight: 600, cursor: "pointer",
                padding: 0, marginBottom: 10, fontFamily: "inherit",
              }}
            >
              <ArrowLeft size={13} /> Home
            </button>
            <div className="eyebrow" style={{ marginBottom: 8 }}>
              {currentProject ? "Project workspace" : "Multi-agent literature review · live pipeline"}
            </div>
            <div className="sm-title">
              <b>Sift</b>{" "}
              <span style={{ color: "var(--muted)", fontWeight: 400 }}>
                / {currentProject ? currentProject.name : "lit-review agent"}
              </span>
            </div>
            <div className="sm-gloss">
              {currentProject
                ? "Every search you run here is filed under this project — papers, notes and review history all stay together."
                : "Enter a research question and watch it move through the agent pipeline — reformulate, search the live web, filter sources, extract, critique, and write a cited review."}
            </div>
          </div>
        </div>

        {/* Project sits up here as a tab rather than in the left rail; it
            opens a drop-down panel. (History is the card under Infinity in
            the rail, and opens the full-size table, HistoryView.) */}
        <div className="sift-tabs">
          {!signedOut && (
            <div className="sift-tab-wrap">
              <button
                className={"sift-tab" + (projectTabOpen ? " on" : "")}
                aria-expanded={projectTabOpen}
                onClick={() => setProjectTabOpen((o) => !o)}
              >
                <Folder size={14} />
                <span>Project</span>
                <b>
                  {currentProject
                    ? currentProject.name
                    : (selectedProject && projects.find((p) => p.id === selectedProject)?.name) || "None"}
                </b>
                <ChevronDown size={13} style={{ opacity: .6 }} />
              </button>
              {projectTabOpen && (
                <>
                  <div className="sift-pop-veil" onClick={() => setProjectTabOpen(false)} />
                  <div className="sift-pop">
              <div className="panel">
                <div style={H.head}>
                  <span className="panel-head-label">Project</span>
                  {!currentProject && (
                    <button style={H.newBtn} onClick={() => setShowProjects(true)} title="Manage projects">
                      <Plus size={14} />
                    </button>
                  )}
                </div>
                {currentProject ? (
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "var(--txt)" }}>{currentProject.name}</div>
                    <div style={{ ...H.empty, padding: "4px 2px 8px" }}>
                      New searches file under this project. Pick a run below to reopen it.
                    </div>
                    {(currentProject.runs || []).length === 0 ? (
                      <div style={{ ...H.empty, padding: "0 2px 8px" }}>No runs in this project yet.</div>
                    ) : (
                      <div style={{ ...H.scroll, maxHeight: 220, marginBottom: 8 }}>
                        {currentProject.runs.map((r) => (
                          <div
                            key={r.id}
                            style={{ ...H.item, ...(r.id === runId ? H.itemActive : {}) }}
                            onClick={() => !busy && restoreSession(r.id)}
                            title={r.topic}
                          >
                            <div style={H.itemTopic}>{r.topic || "Untitled review"}</div>
                            <div style={H.meta}>
                              <span style={{ ...H.badge, ...(r.stage === "done" ? H.badgeDone : H.badgeFilter) }}>
                                {r.stage === "done" ? "✓ review" : "◦ filter"}
                              </span>
                              <span style={H.dot}>·</span>
                              <span>{r.paper_count}p</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    <div style={{ display: "flex", gap: 6 }}>
                      <button style={H.newBtn} onClick={() => { reset(); setTopic(""); }}>+ New search</button>
                      <button style={H.newBtn} onClick={() => setShowProjects(true)}>Manage</button>
                      <button style={H.newBtn} onClick={exitProject}>Exit project</button>
                    </div>
                  </div>
                ) : stage === "query" ? (
                  <div style={{ position: "relative" }}>
                    <button
                      type="button"
                      style={PICK.chip}
                      onClick={() => { setPickerNewOpen(false); setProjectPickerOpen((o) => !o); }}
                    >
                      <Folder size={13} />
                      <span style={PICK.chipLabel}>
                        {selectedProject
                          ? (projects.find((p) => p.id === selectedProject)?.name || "Project")
                          : "File under a project…"}
                      </span>
                      <ChevronDown size={13} style={{ flexShrink: 0, opacity: .6 }} />
                    </button>

                    {projectPickerOpen && (
                      <div style={NEWMENU.menu} onClick={(e) => e.stopPropagation()}
                        onMouseLeave={() => { if (!pickerNewOpen) setProjectPickerOpen(false); }}>
                        <button
                          style={{ ...NEWMENU.item, ...(!selectedProject ? PICK.itemActive : {}) }}
                          onClick={() => { setSelectedProject(""); setProjectPickerOpen(false); }}
                        >
                          No project (unfiled)
                        </button>
                        {projects.map((p) => (
                          <button
                            key={p.id}
                            style={{ ...NEWMENU.item, ...(p.id === selectedProject ? PICK.itemActive : {}) }}
                            onClick={() => { setSelectedProject(p.id); setProjectPickerOpen(false); }}
                          >
                            {p.id === selectedProject ? "✓ " : ""}{p.name}
                          </button>
                        ))}
                        {projects.length === 0 && !pickerNewOpen && (
                          <div style={{ ...H.empty, padding: "4px 9px" }}>No projects yet.</div>
                        )}
                        {pickerNewOpen ? (
                          <form onSubmit={createProjectAndSelect} style={{ padding: 6 }}>
                            <input autoFocus style={NEWMENU.input} placeholder="Project name"
                              value={pickerNewName} onChange={(e) => setPickerNewName(e.target.value)} />
                            <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
                              <button type="submit" disabled={pickerBusy} className="btn sm" style={{ flex: 1 }}>
                                {pickerBusy ? "Creating…" : "Create & select"}
                              </button>
                            </div>
                          </form>
                        ) : (
                          <button style={{ ...NEWMENU.item, color: "var(--indigo)" }}
                            onClick={() => setPickerNewOpen(true)}>
                            + New project
                          </button>
                        )}
                      </div>
                    )}

                    {!selectedProject && projects.length === 0 && (
                      <div style={{ ...H.empty, padding: "6px 2px 0" }}>
                        File this search under a project to keep its papers, notes and history together.
                      </div>
                    )}
                  </div>
                ) : null}
              </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
        {historyOpen && !signedOut && (
          <HistoryView
            sessions={sessions} projects={projects} tz={profileTz} activeId={runId} busy={busy}
            onOpen={restoreSession} onDelete={deleteSession} onFile={fileSessionUnderProject}
            onClose={() => setHistoryOpen(false)}
          />
        )}

        <div className="grid3">
          {/* LEFT: Tools + Infinity */}
          <div className="lcol">
            <div style={{ position: "relative" }}>
              <button
                className="btn"
                disabled={busy}
                onClick={() => setNewMenuOpen((o) => !o)}
                style={{ width: "100%", justifyContent: "center", display: "flex", alignItems: "center", gap: 6 }}
              >
                <Plus size={14} /> New {newMenuOpen ? "▴" : "▾"}
              </button>
              {newMenuOpen && (
                <div style={NEWMENU.menu} onMouseLeave={() => setNewMenuOpen(false)}>
                  {currentProject && (
                    <button style={NEWMENU.item2} onClick={() => { setNewMenuOpen(false); if (!busy) startNewSearchInProject(); }}>
                      <span style={NEWMENU.itemIc}><Plus size={15} /></span>
                      <span>
                        <span style={NEWMENU.itemTitle}>New search in this project</span>
                        <span style={NEWMENU.itemSub}>A fresh question, filed under {currentProject.name}</span>
                      </span>
                    </button>
                  )}
                  <button style={NEWMENU.item2} onClick={() => { setNewMenuOpen(false); if (!busy) startNewChat(); }}>
                    <span style={NEWMENU.itemIc}><MessageSquare size={15} /></span>
                    <span>
                      <span style={NEWMENU.itemTitle}>{currentProject ? "New chat outside the project" : "New chat"}</span>
                      <span style={NEWMENU.itemSub}>
                        {currentProject ? "Leaves this project and starts a stand-alone question" : "Start a fresh research question"}
                      </span>
                    </span>
                  </button>
                  <button style={NEWMENU.item2} onClick={() => { setNewMenuOpen(false); setNewProjectOpen(true); }}>
                    <span style={NEWMENU.itemIc}><Folder size={15} /></span>
                    <span>
                      <span style={NEWMENU.itemTitle}>New project</span>
                      <span style={NEWMENU.itemSub}>Group searches, papers &amp; notes together</span>
                    </span>
                  </button>
                  <button style={NEWMENU.item2} onClick={() => { setNewMenuOpen(false); setShowProjects(true); }}>
                    <span style={NEWMENU.itemIc}><Layers size={15} /></span>
                    <span>
                      <span style={NEWMENU.itemTitle}>Open existing project</span>
                      <span style={NEWMENU.itemSub}>Browse, share &amp; manage your projects</span>
                    </span>
                  </button>
                </div>
              )}
              {newProjectOpen && (
                <form onSubmit={createProjectAndOpen} style={NEWMENU.popover}>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 6 }}>New project</div>
                  <input autoFocus style={NEWMENU.input} placeholder="Project name"
                    value={newProjectName} onChange={(e) => setNewProjectName(e.target.value)} />
                  <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
                    <button type="submit" disabled={newProjectBusy} className="btn sm" style={{ flex: 1 }}>
                      {newProjectBusy ? "Creating…" : "Create & open"}
                    </button>
                    <button type="button" className="btn ghost sm" onClick={() => setNewProjectOpen(false)}>Cancel</button>
                  </div>
                  {newProjectErr && <div style={{ color: "#f08a8a", fontSize: 11.5, marginTop: 6 }}>{newProjectErr}</div>}
                </form>
              )}
            </div>

            <div className="panel">
              <div className="panel-head-label" style={{ marginBottom: 12 }}>Tools</div>
              {TOOLS.map(([k, Ic, lab]) => {
                const enabled = isDone;
                return (
                  <button
                    key={k}
                    className={"tool-item" + (enabled && tab === k ? " on" : "") + (enabled ? "" : " disabled")}
                    disabled={!enabled}
                    onClick={() => {
                      if (!enabled) return;
                      // Studio opens as a full-screen overlay (see below) —
                      // remember what was showing underneath so Back returns
                      // to it instead of an arbitrary tab.
                      if (k === "studio" && tab !== "studio") setPrevTab(tab);
                      setTab(k);
                    }}
                  >
                    <Ic size={14} /> {lab}
                  </button>
                );
              })}
            </div>

            {/* Studio is a workspace of its own (chat, report, deck, briefing
                across the sources), so it sits beside Infinity as its own
                card rather than as a row in Tools. */}
            <div className={"panel hyp-cta" + (tab === "studio" ? " on" : "")}>
              <div className="hyp-cta-head">
                <span className="hyp-cta-ic"><MessageSquare size={15} /></span>
                <span className="hyp-cta-kicker">Studio</span>
              </div>
              <div className="hyp-cta-title">Want to understand these papers better?</div>
              <div className="hyp-cta-body">
                {isDone
                  ? "Ask questions across your sources, or turn them into a report, slide deck or briefing."
                  : "Studio opens once your sources have been read. Run a review, or add your own papers first."}
              </div>
              <button
                className="btn sm" style={{ width: "100%" }} disabled={!isDone}
                onClick={() => { if (tab !== "studio") setPrevTab(tab); setTab("studio"); }}
              >
                Open Studio →
              </button>
            </div>

            {/* Infinity (hypothesis generation) is a separate agent, so it is a
                call-out of its own rather than one more row in Tools. With a
                finished review it opens on that review; without one it opens
                the picker for a past review. */}
            <div className={"panel hyp-cta" + (tab === "hypothesis" ? " on" : "")}>
              <div className="hyp-cta-head">
                <span className="hyp-cta-ic"><Lightbulb size={15} /></span>
                <span className="hyp-cta-kicker">Infinity</span>
              </div>
              <div className="hyp-cta-title">Want to generate hypotheses?</div>
              <div className="hyp-cta-body">
                {isDone
                  ? "Turn this review's findings into ranked, testable hypotheses."
                  : "Infinity builds hypotheses from a finished literature review. Run one here, or start from a past review."}
              </div>
              <button
                className="btn sm" style={{ width: "100%" }}
                onClick={() => {
                  // Always the Hypothesis Generation workspace, never an in-page
                  // tab. With a finished review loaded, it opens on THIS review.
                  if (!isDone) { openHypothesisWorkspaceBlank(); return; }
                  setHypTab("hypothesis"); setPinnedHypRunId(null); setSwitchProjectOpen(false);
                  setView("hypothesis-workspace");
                }}
              >
                {isDone ? "Generate hypotheses →" : "Use a past review →"}
              </button>
            </div>

            {/* Publish: the step after the review (and Infinity, if run) --
                write it up in a journal's own Word or LaTeX template. */}
            {isDone && (
              <button className="hist-entry" style={{ marginBottom: 10 }} onClick={() => setTab("publish")}>
                <span className="hist-entry-ic"><PenTool size={15} /></span>
                <span className="hist-entry-txt">
                  <b>Publish</b>
                  <small>Write it up in a journal's format</small>
                </span>
                <span className="hist-entry-go" aria-hidden="true">→</span>
              </button>
            )}

            {/* History: one row here, the full table opens on click. */}
            <button className="hist-entry" onClick={() => (signedOut ? ensureAuth() : setHistoryOpen(true))}>
              <span className="hist-entry-ic"><Clock size={15} /></span>
              <span className="hist-entry-txt">
                <b>History</b>
                <small>
                  {signedOut ? "Log in to see your saved runs"
                    : sessions.length === 0 ? "No runs yet"
                    : `${sessions.length} saved ${sessions.length === 1 ? "run" : "runs"}`}
                </small>
              </span>
              <span className="hist-entry-go" aria-hidden="true">→</span>
            </button>

          </div>

          {/* CENTER: Model selection + prompt / stage content */}
          <div className="ccol">
            {/* Sticky + same top offset as the Tools/Project/History rail
                (lcol) and the Agent Pipeline rail (rcol) — otherwise this
                scrolls out of sync with them and no longer lines up once
                the page is scrolled. */}
            <div style={{
              marginBottom: 16, display: "flex", justifyContent: "flex-end",
              position: "sticky", top: 18, zIndex: 5, background: "var(--ink)", paddingBottom: 4,
            }}>
              <ModeBar modes={modes} mode={mode} setMode={setMode} apiKey={apiKey} setApiKey={setApiKey} />
            </div>

            {planNotice && (
              <div style={{
                marginBottom: 16, padding: "10px 14px", borderRadius: 10, fontSize: 13,
                background: "rgba(224,163,62,.12)", border: "1px solid rgba(224,163,62,.45)",
                display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap",
              }}>
                <span>{planNotice}</span>
                <span style={{ display: "flex", gap: 8 }}>
                  <button className="btn sm" onClick={() => setView("billing")}>See plans</button>
                  <button className="btn ghost sm" onClick={() => setPlanNotice(null)}>Dismiss</button>
                </span>
              </div>
            )}

            {error && (
              <div className="err" style={{ marginBottom: 16 }}>
                <AlertTriangle size={18} style={{ flex: "0 0 18px", marginTop: 1 }} />
                <div>
                  <b>{error.stage} failed.</b> {error.msg}
                  <div style={{ marginTop: 8 }}>
                    <button
                      className="btn ghost sm"
                      onClick={() => {
                        const retry = error.retry || (papers.length ? runApprove : runStart);
                        setError(null);
                        retry();
                      }}
                    >
                      <RotateCw size={13} /> Retry stage
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Don't compete with the Token Usage card below: before any run
                starts, stage stays "query" indefinitely, and Token Usage is
                the one tab reachable at that point (see `enabled` above) —
                without this check both the topic-input form AND the usage
                card would stack in the same column, making usage look like
                it "doesn't show" until you scroll past the form, or start a
                run (which permanently moves stage off "query"). */}
            {stage === "query" && tab !== "usage" && (
              <QueryInput topic={topic} setTopic={setTopic} busy={busy} onRun={runStart}
                onAnalyzeDocs={startAnalyzeDocs} />
            )}

            {busy && (stage === "reformulate" || stage === "search") && (
              reform ? (
                <UnderstandingCard topic={topic} reform={reform} progressMsgs={progressMsgs} stage={stage} />
              ) : (
                <div className="card">
                  <div className="card-h">
                    <div className="ic"><RotateCw size={16} className="spin" /></div>
                    <h3>{stage === "reformulate" ? "Query Reformulator" : "Academic Search"}</h3>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 4 }}>
                    {progressMsgs.length === 0 && (
                      <div className="muted tiny pulse">Starting up…</div>
                    )}
                    {progressMsgs.map((ev, i) => {
                      const isLatest = i === progressMsgs.length - 1;
                      const icon = SOURCE_ICON[ev.detail] || (ev.step === "reformulate" ? "🤖" : "🔍");
                      return (
                        <div key={i} style={{
                          display: "flex", alignItems: "flex-start", gap: 8,
                          opacity: isLatest ? 1 : 0.45,
                          fontSize: 12, lineHeight: 1.5,
                          transition: "opacity 0.3s",
                        }}>
                          <span style={{ fontSize: 14, flexShrink: 0, marginTop: 1 }}>{icon}</span>
                          <span style={{ color: isLatest ? "var(--fg)" : "var(--muted)" }}>
                            {ev.message}
                            {isLatest && <span className="pulse" style={{ marginLeft: 4 }}>…</span>}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )
            )}

            {stage === "filter" && papers.length > 0 && (
              <PaperFilter
                papers={papers}
                approved={approved}
                scope={reform?.scope}
                busy={busy}
                onToggle={(idx) => setApproved((a) => ({ ...a, [idx]: !a[idx] }))}
                onApprove={runApprove}
                onRestart={reset}
                runId={runId}
                apiKey={apiKey}
                model={model}
                notes={notes}
                onNote={(idx, text) => setNotes((n) => ({ ...n, [idx]: text }))}
              />
            )}

            {busy && (stage === "extract" || stage === "synthesize") && (
              <div className="card">
                <div className="card-h">
                  <div className="ic"><RotateCw size={16} className="spin" /></div>
                  <h3>Reader &amp; Extractor / Critic &amp; Synthesizer</h3>
                  <span className="tag">{stage === "synthesize" ? "synthesizing…" : "reading…"}</span>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 5, marginTop: 4, maxHeight: 300, overflowY: "auto" }}>
                  {progressMsgs.length === 0 && (
                    <div className="muted tiny pulse">Reading papers…</div>
                  )}
                  {progressMsgs.map((ev, i) => {
                    const isLatest = i === progressMsgs.length - 1;
                    const icon = ev.step === "synthesize" ? "🧩" : "📄";
                    return (
                      <div key={i} style={{
                        display: "flex", alignItems: "flex-start", gap: 8,
                        opacity: isLatest ? 1 : 0.5, fontSize: 12, lineHeight: 1.5,
                        transition: "opacity 0.3s",
                      }}>
                        <span style={{ fontSize: 13, flexShrink: 0, marginTop: 1 }}>{icon}</span>
                        <span style={{ color: isLatest ? "var(--fg)" : "var(--muted)" }}>
                          {ev.message}
                          {isLatest && <span className="pulse" style={{ marginLeft: 4 }}>…</span>}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {busy && stage === "write" && (
              <div className="card">
                <div className="card-h">
                  <div className="ic"><RotateCw size={16} className="spin" /></div>
                  <h3>Writer Agent</h3>
                </div>
                <div className="muted tiny pulse">
                  Reading your kept papers and drafting the review — introduction, thematic synthesis, gaps, and conclusion…
                </div>
              </div>
            )}

            {isDone && (
              <div ref={reviewRef}>
                <div className="card">
                  {tab === "review" && (
                    Object.keys(sections || {}).length > 0
                      ? <>
                          <ExportBar runId={runId} onError={(m) => setError({ stage: "Export", msg: m })} />
                          <ReviewView topic={topic} sections={sections} citeOrder={citeOrder} />
                        </>
                      : (
                        <div style={{ textAlign: "center", padding: "28px 16px" }}>
                          <div className="eyebrow" style={{ marginBottom: 8 }}></div>
                          <h3 style={{ margin: "0 0 8px", fontSize: 16 }}>No written review yet</h3>
                          <div className="muted tiny" style={{ maxWidth: 460, margin: "0 auto 16px", lineHeight: 1.6 }}>
                            Your papers are reviewed and ready to explore in Sources, Critique and the
                            other tools. If you'd like, the Writer agent can draft a cited literature
                            review from your kept papers.
                          </div>
                          <button className="btn" disabled={busy || analysisStale} onClick={runWrite}>
                            <PenTool size={15} /> Generate cited review
                          </button>
                          {analysisStale && (
                            <div className="muted tiny" style={{ marginTop: 10 }}>
                              Update the analysis on the Sources tab first.
                            </div>
                          )}
                        </div>
                      )
                  )}
                  {tab === "sources" && (
                    <SourcesView
                      citeOrder={citeOrder} extractions={extractions} ranked={synth?.ranked}
                      extractStats={extractStats} runId={runId} apiKey={apiKey} model={model}
                      papers={papers} included={included} scope={reform?.scope}
                      analysisStale={analysisStale} busy={busy}
                      onRemove={removeSources} onAdd={addPaperToSources}
                      onUpload={uploadPaperToSources}
                      onReanalyze={reanalyzeSources} onGenerate={runWrite}
                      hasReview={Object.keys(sections || {}).length > 0}
                    />
                  )}
                  {tab === "critique" && <CritiqueView synth={synth} />}
                  {tab === "graph" && (
                    <KnowledgeGraphView concepts={sideModules?.knowledge_graph} citeNum={citeNum} papers={citeOrder} />
                  )}
                  {tab === "data" && (
                    <DataAnalysisView
                      reform={reform}
                      yearDistribution={sideModules?.year_distribution}
                      comparisonTable={sideModules?.comparison_table}
                    />
                  )}
                  {tab === "eval" && <EvaluationView evalRes={evalRes} busy={busy} onEvaluate={runEvaluate} />}
                  {tab === "methods" && (
                    <MethodsPanel
                      plan={experimentPlan}
                      critique={experimentCritique}
                      iterations={experimentIterations}
                      debate={experimentDebate}
                      kgBridges={experimentKgBridges}
                      busy={busy}
                      onDesign={runDesignExperiments}
                      onRefine={runRefineExperiments}
                      onUpdate={updateHypothesis}
                      onDispute={disputeHypothesis}
                      onAcceptRevision={acceptRevision}
                      onExport={exportExperiments}
                      papers={papers}
                      extractions={extractions}
                    />
                  )}
                  {tab === "publish" && (
                    <PublishPanel runId={runId} hypRunId={hypothesisRun?.id} apiKey={apiKey} model={model} topic={topic} />
                  )}
                  {tab === "hypothesis" && (
                    <HypothesisAgentPanel
                      runId={runId}
                      busy={hypothesisBusy}
                      result={hypothesisRun}
                      error={hypothesisError}
                      onRun={runHypothesisPipeline}
                      papers={papers}
                      extractions={extractions}
                      onCheckResults={checkHypothesisResults}
                      onApplyRefinement={applyHypothesisRefinement}
                      resultsCheckBusy={resultsCheckBusy}
                      resultsCheckError={resultsCheckError}
                      onReverifyRefinement={reverifyHypothesisRefinement}
                      reverifyBusy={reverifyBusy}
                      reverifyError={reverifyError}
                      onDisputeMetaReview={disputeMetaReview}
                      onApplyDispute={applyHypothesisDispute}
                      disputeBusy={disputeBusy}
                      disputeError={disputeError}
                    />
                  )}
                </div>

                <div style={{ marginTop: 16, display: "flex", gap: 10, flexWrap: "wrap" }}>
                  <button className="btn ghost" onClick={() => { const old = topic; reset(); setTopic(old); }}>
                    <RotateCw size={14} /> New run
                  </button>
                  <button className="btn ghost" onClick={() => { reset(); setTopic(""); }}>
                    <Sparkles size={14} /> New topic
                  </button>
                  <span style={{ width: 1, alignSelf: "stretch", background: "var(--line)", margin: "0 2px" }} />
                  <button className="btn ghost sm" disabled={!citeOrder.length} onClick={() => exportShortlist("md")}>Export .md</button>
                  <button className="btn ghost sm" disabled={!citeOrder.length} onClick={() => exportShortlist("bib")}>Export .bib</button>
                </div>
              </div>
            )}

            {/* Token usage stands alone from the pipeline stage — usable with
                no active run (falls back to the all-time spend trend) or
                mid-run/done (shows this session's live totals so far). Kept
                outside the {isDone && ...} block above so it doesn't need a
                finished run to be reachable. */}
            {tab === "usage" && (
              <div className="card">
                <UsageView runId={runId} />
              </div>
            )}

          </div>

          {/* Agent Pipeline status — swaps to the Hypothesis Agent's own
              rail while that tab is open, since a Hypothesis pipeline run
              is a separate agent run from Sift's and deserves its own
              visible progress rather than the Sift rail sitting frozen. */}
          <div className="rcol">
            {tab === "hypothesis" ? (
              <HypothesisPipelineRail
                stage={hypothesisStage}
                busy={hypothesisBusy}
                done={hypothesisStageDone}
                live={hypothesisLive}
              />
            ) : (
              <PipelineRail
                stage={stage}
                busy={busy}
                done={done}
                kg={sideModules?.knowledge_graph}
                ranked={synth?.ranked?.length}
                dataReady={!!sideModules}
                models={pipelineModels}
                showMemory={false}
                hasPlan={!!experimentPlan}
              />
            )}
          </div>
        </div>
      </div>
        )}
        </div>
      </div>
    </div>
  );
}
